import React, { useState, useEffect } from "react";
import {
  CheckSquare, AlertCircle, Clock, CheckCircle2, Upload, FileText,
  ShieldCheck, X, Loader2
} from "lucide-react";
import { correctiveActionService, mineService } from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function CorrectiveActionsPage() {
  const { role } = useAuth();
  const [actions, setActions] = useState([]);
  const [mines, setMines] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [statusFilter, setStatusFilter] = useState("");
  const [overdueOnly, setOverdueOnly] = useState(false);
  const [mineFilter, setMineFilter] = useState("");

  // Evidence / Verification Modal
  const [selectedAction, setSelectedAction] = useState(null);
  const [modalMode, setModalMode] = useState("evidence"); // "evidence" or "verify"
  const [evidenceName, setEvidenceName] = useState("");
  const [officerNotes, setOfficerNotes] = useState("");
  const [verificationDecision, setVerificationDecision] = useState("COMPLETED");

  const fetchData = () => {
    setLoading(true);
    Promise.all([
      correctiveActionService.getAll({
        status: statusFilter || undefined,
        overdue_only: overdueOnly || undefined,
        mine_id: mineFilter || undefined
      }),
      mineService.getAll({ limit: 50 })
    ])
      .then(([caRes, mRes]) => {
        setActions(caRes.data);
        setMines(mRes.data);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchData();
  }, [statusFilter, overdueOnly, mineFilter]);

  const handleOpenAction = (action, mode) => {
    setSelectedAction(action);
    setModalMode(mode);
    setEvidenceName(action.evidence || "DGMS_Compliance_Cert_2026.pdf");
    setOfficerNotes(action.officer_notes || "Field inspection and air volume audit confirmed compliant.");
  };

  const handleSaveModal = async (e) => {
    e.preventDefault();
    if (!selectedAction) return;

    try {
      if (modalMode === "evidence") {
        await correctiveActionService.update(selectedAction.id, {
          evidence: evidenceName,
          status: "SUBMITTED"
        });
      } else {
        await correctiveActionService.update(selectedAction.id, {
          officer_notes: officerNotes,
          status: verificationDecision
        });
      }
      setSelectedAction(null);
      fetchData();
    } catch (err) {
      alert("Failed to update corrective action.");
    }
  };

  const getStatusBadge = (status, isOverdue) => {
    if (isOverdue || status === "OVERDUE") {
      return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-950 text-red-400 border border-red-800 animate-pulse">OVERDUE</span>;
    }
    switch (status) {
      case "COMPLETED":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">COMPLETED</span>;
      case "SUBMITTED":
      case "VERIFICATION":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-800">VERIFICATION PENDING</span>;
      case "IN PROGRESS":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-400 border border-amber-800">IN PROGRESS</span>;
      case "PENDING":
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">PENDING</span>;
    }
  };

  const isOfficer = role === "GOVERNMENT_OFFICER" || role === "SUPER_ADMIN";

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <CheckSquare className="w-6 h-6 text-emerald-400" />
            Corrective & Remedial Action Plans (CAPA)
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Enforcing statutory remediation SLAs, evidence verification, and risk sign-off.
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Status</label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Action Statuses</option>
            <option value="PENDING">Pending</option>
            <option value="IN PROGRESS">In Progress</option>
            <option value="SUBMITTED">Submitted</option>
            <option value="COMPLETED">Completed</option>
            <option value="OVERDUE">Overdue</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Mine</label>
          <select
            value={mineFilter}
            onChange={(e) => setMineFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Mines</option>
            {mines.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-2 flex items-end">
          <label className="flex items-center gap-2 py-2 px-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 cursor-pointer w-full">
            <input
              type="checkbox"
              checked={overdueOnly}
              onChange={(e) => setOverdueOnly(e.target.checked)}
              className="rounded border-slate-700 bg-slate-900 text-red-500 focus:ring-red-500"
            />
            <span className="font-semibold text-red-400">Show Overdue Actions Only</span>
          </label>
        </div>
      </div>

      {/* Corrective Actions Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Action Code</th>
                <th className="py-3 px-3">Mine</th>
                <th className="py-3 px-3">Violation Linked</th>
                <th className="py-3 px-3">Remediation Description</th>
                <th className="py-3 px-3">Assigned Lead</th>
                <th className="py-3 px-3">SLA Due Date</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Workflow</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-400" />
                    <span>Loading corrective actions...</span>
                  </td>
                </tr>
              ) : actions.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-500">
                    No corrective actions found matching criteria.
                  </td>
                </tr>
              ) : (
                actions.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-white">
                      {a.action_code || `CA-${a.id}`}
                    </td>
                    <td className="py-3.5 px-3 font-semibold text-white">
                      {a.mine_name}
                    </td>
                    <td className="py-3.5 px-3 font-mono text-[10px] text-orange-400">
                      {a.violation_code}
                    </td>
                    <td className="py-3.5 px-3 max-w-xs truncate text-slate-300">
                      {a.description}
                    </td>
                    <td className="py-3.5 px-3 text-slate-300">
                      {a.assigned_person}
                    </td>
                    <td className="py-3.5 px-3 font-mono text-[11px] text-slate-400">
                      {new Date(a.due_date).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-3">
                      {getStatusBadge(a.status, a.is_overdue)}
                    </td>
                    <td className="py-3.5 px-3 text-right space-x-2">
                      {a.status !== "COMPLETED" && (
                        <>
                          <button
                            onClick={() => handleOpenAction(a, "evidence")}
                            className="px-2.5 py-1 rounded-lg text-xs font-semibold text-indigo-300 hover:text-white bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-800 transition"
                          >
                            Submit Evidence
                          </button>
                          {isOfficer && (
                            <button
                              onClick={() => handleOpenAction(a, "verify")}
                              className="px-2.5 py-1 rounded-lg text-xs font-semibold text-emerald-300 hover:text-white bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800 transition"
                            >
                              Verify
                            </button>
                          )}
                        </>
                      )}
                      {a.status === "COMPLETED" && (
                        <span className="text-[11px] text-emerald-400 font-semibold">
                          Signed Off
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Action Modal (Evidence / Officer Verification) */}
      {selectedAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">
                {modalMode === "evidence" ? "Upload Remediation Evidence" : "Officer Verification & Sign-off"}
              </h3>
              <button onClick={() => setSelectedAction(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs space-y-1">
              <div className="font-semibold text-white">{selectedAction.action_code} — {selectedAction.mine_name}</div>
              <p className="text-slate-400">{selectedAction.description}</p>
            </div>

            <form onSubmit={handleSaveModal} className="space-y-3 text-xs">
              {modalMode === "evidence" ? (
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">
                    Remediation Document / Certificate
                  </label>
                  <input
                    type="text"
                    value={evidenceName}
                    onChange={(e) => setEvidenceName(e.target.value)}
                    placeholder="e.g. DGMS_Auxiliary_Fan_Replacement_Report.pdf"
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Acceptable formats: PDF, JPG, PNG, DOCX.
                  </p>
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">
                      Verification Decision
                    </label>
                    <select
                      value={verificationDecision}
                      onChange={(e) => setVerificationDecision(e.target.value)}
                      className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                    >
                      <option value="COMPLETED">Approved & Completed (Closes Violation)</option>
                      <option value="IN PROGRESS">Reject & Request Additional Remediation</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-300 font-semibold mb-1">
                      Statutory Officer Verification Notes
                    </label>
                    <textarea
                      rows={3}
                      value={officerNotes}
                      onChange={(e) => setOfficerNotes(e.target.value)}
                      className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                    />
                  </div>
                </>
              )}

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedAction(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 font-bold text-white rounded-lg"
                >
                  {modalMode === "evidence" ? "Submit Remediation Evidence" : "Confirm Sign-off"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
