import os
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

logger = logging.getLogger("coalguard.database")

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "mysql+pymysql://root:password@localhost:3306/coalguard_ai"
)

# Resilient connection fallback: try MySQL, if not reachable fallback to local SQLite
try:
    if DATABASE_URL.startswith("sqlite"):
        engine = create_engine(
            DATABASE_URL,
            connect_args={"check_same_thread": False}
        )
    else:
        # Try MySQL
        engine = create_engine(
            DATABASE_URL,
            pool_recycle=3600,
            pool_pre_ping=True
        )
        # Test connection
        with engine.connect() as conn:
            logger.info("Connected to configured database successfully.")
except Exception as e:
    logger.warning(
        f"Configured database ({DATABASE_URL}) connection failed: {e}. "
        "Falling back to local SQLite database (coalguard.db) for reliable runtime."
    )
    SQLITE_URL = "sqlite:///./coalguard.db"
    engine = create_engine(
        SQLITE_URL,
        connect_args={"check_same_thread": False}
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
