import React, { useState, useEffect } from "react";
import { History, Shield, Search, Filter, Lock, Loader2 } from "lucide-react";
import { auditService } from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function AuditLogsPage() {
  const { role } = useAuth();
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [actionSearch, setActionSearch] = useState("");
  const [entityFilter, setEntityFilter] = useState("");

  const isAuthorized = role === "SUPER_ADMIN" || role === "GOVERNMENT_OFFICER";

  const fetchLogs = () => {
    if (!isAuthorized) return;
    setLoading(true);
    auditService.getAll({
      action: actionSearch || undefined,
      entity: entityFilter || undefined
    })
      .then((res) => setLogs(res.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchLogs();
  }, [actionSearch, entityFilter]);

  if (!isAuthorized) {
    return (
      <div className="py-24 text-center space-y-3">
        <Lock className="w-10 h-10 text-red-400 mx-auto" />
        <h2 className="text-lg font-bold text-white">Access Restricted</h2>
        <p className="text-xs text-slate-400 max-w-sm mx-auto">
          Audit logs are strictly confidential and restricted to Super Admins and Government Mining Officers.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <History className="w-6 h-6 text-emerald-400" />
            Statutory Immutable Governance Audit Trail
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Tamper-evident logs of all supervisory actions, inspections, telemetry anomalies, and sign-offs.
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search action or user (e.g. Violation, Inspection, Login)..."
            value={actionSearch}
            onChange={(e) => setActionSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div>
          <select
            value={entityFilter}
            onChange={(e) => setEntityFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Entities</option>
            <option value="User">User</option>
            <option value="Mine">Mine</option>
            <option value="Violation">Violation</option>
            <option value="Inspection">Inspection</option>
            <option value="CorrectiveAction">Corrective Action</option>
            <option value="Compliance">Compliance</option>
            <option value="Alert">Alert</option>
            <option value="Simulation">Simulation</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-3">Actor (User)</th>
                <th className="py-3 px-3">Action</th>
                <th className="py-3 px-3">Entity</th>
                <th className="py-3 px-3">Details</th>
                <th className="py-3 px-3">Client IP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="6" className="py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-400" />
                    <span>Querying secure audit ledger...</span>
                  </td>
                </tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan="6" className="py-12 text-center text-slate-500">
                    No audit records matching search criteria.
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-mono text-slate-400 text-[11px]">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3.5 px-3 font-semibold text-white">
                      {log.user_email}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="font-semibold text-emerald-400">{log.action}</span>
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                        {log.entity}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 max-w-md truncate text-slate-300">
                      {log.details}
                    </td>
                    <td className="py-3.5 px-3 font-mono text-[11px] text-slate-500">
                      {log.ip_address}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
