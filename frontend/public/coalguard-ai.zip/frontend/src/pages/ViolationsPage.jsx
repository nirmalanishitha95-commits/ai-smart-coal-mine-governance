import React, { useState, useEffect } from "react";
import {
  AlertOctagon, Search, Filter, Eye, Edit2, X, AlertTriangle,
  Clock, DollarSign, User, Calendar, Loader2
} from "lucide-react";
import { violationService, mineService } from "../services/api";
import RiskBadge from "../components/RiskBadge";

export default function ViolationsPage() {
  const [violations, setViolations] = useState([]);
  const [mines, setMines] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [severityFilter, setSeverityFilter] = useState("");
  const [mineFilter, setMineFilter] = useState("");

  // Edit / Details Modal
  const [selectedViolation, setSelectedViolation] = useState(null);
  const [editStatus, setEditStatus] = useState("OPEN");
  const [editFine, setEditFine] = useState(0);
  const [editOfficer, setEditOfficer] = useState("");

  const fetchData = () => {
    setLoading(true);
    Promise.all([
      violationService.getAll({
        search: search || undefined,
        status: statusFilter || undefined,
        severity: severityFilter || undefined,
        mine_id: mineFilter || undefined
      }),
      mineService.getAll({ limit: 50 })
    ])
      .then(([vRes, mRes]) => {
        setViolations(vRes.data);
        setMines(mRes.data);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchData();
  }, [search, statusFilter, severityFilter, mineFilter]);

  const handleOpenEdit = (v) => {
    setSelectedViolation(v);
    setEditStatus(v.status);
    setEditFine(v.fine_amount || 0);
    setEditOfficer(v.assigned_officer || "Er. Rajesh Kumar");
  };

  const handleSaveStatus = async (e) => {
    e.preventDefault();
    if (!selectedViolation) return;
    try {
      await violationService.update(selectedViolation.id, {
        status: editStatus,
        fine_amount: parseFloat(editFine),
        assigned_officer: editOfficer
      });
      setSelectedViolation(null);
      fetchData();
    } catch (err) {
      alert("Failed to update violation status.");
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "RESOLVED":
      case "CLOSED":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">{status}</span>;
      case "CORRECTIVE ACTION":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950 text-amber-400 border border-amber-800">CORRECTIVE ACTION</span>;
      case "UNDER REVIEW":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-950 text-blue-400 border border-blue-800">UNDER REVIEW</span>;
      case "OPEN":
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-950 text-red-400 border border-red-800">OPEN</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <AlertOctagon className="w-6 h-6 text-orange-400" />
            Statutory Violation & Enforcement Registry
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Official DGMS non-compliance orders, stop-work directives, and environmental penalties.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search code or description..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div>
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Severities</option>
            <option value="CRITICAL">Critical</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Statuses</option>
            <option value="OPEN">Open</option>
            <option value="UNDER REVIEW">Under Review</option>
            <option value="CORRECTIVE ACTION">Corrective Action</option>
            <option value="RESOLVED">Resolved</option>
            <option value="CLOSED">Closed</option>
          </select>
        </div>

        <div>
          <select
            value={mineFilter}
            onChange={(e) => setMineFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Mines</option>
            {mines.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Violations Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Violation Code</th>
                <th className="py-3 px-3">Target Mine</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3">Severity</th>
                <th className="py-3 px-3">Description</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Assigned Officer</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-orange-400" />
                    <span>Loading violations directory...</span>
                  </td>
                </tr>
              ) : violations.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-500">
                    No violations found for current query.
                  </td>
                </tr>
              ) : (
                violations.map((v) => (
                  <tr key={v.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-white">
                      {v.violation_code}
                    </td>
                    <td className="py-3.5 px-3 font-semibold text-white">
                      {v.mine_name}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                        {v.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-3">
                      <RiskBadge level={v.severity} showScore={false} size="sm" />
                    </td>
                    <td className="py-3.5 px-3 max-w-xs truncate text-slate-300">
                      {v.description}
                    </td>
                    <td className="py-3.5 px-3">
                      {getStatusBadge(v.status)}
                    </td>
                    <td className="py-3.5 px-3 text-slate-400">
                      {v.assigned_officer || "DGMS Officer"}
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      <button
                        onClick={() => handleOpenEdit(v)}
                        className="px-2.5 py-1 rounded-lg text-xs font-semibold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
                      >
                        Details
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Details & Status Update Modal */}
      {selectedViolation && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold text-white">
                  Statutory Violation {selectedViolation.violation_code}
                </h3>
                <p className="text-[11px] text-slate-400">{selectedViolation.mine_name}</p>
              </div>
              <button onClick={() => setSelectedViolation(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-semibold">Category:</span>
                <span className="text-slate-200">{selectedViolation.category}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400 font-semibold">Severity:</span>
                <RiskBadge level={selectedViolation.severity} showScore={false} size="sm" />
              </div>
              <div className="pt-1">
                <span className="text-slate-400 font-semibold block mb-0.5">Description:</span>
                <p className="text-slate-300 leading-relaxed">{selectedViolation.description}</p>
              </div>
            </div>

            <form onSubmit={handleSaveStatus} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Update Status</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                >
                  <option value="OPEN">OPEN</option>
                  <option value="UNDER REVIEW">UNDER REVIEW</option>
                  <option value="CORRECTIVE ACTION">CORRECTIVE ACTION</option>
                  <option value="RESOLVED">RESOLVED</option>
                  <option value="CLOSED">CLOSED</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Fine Penalty (₹ INR)</label>
                <input
                  type="number"
                  value={editFine}
                  onChange={(e) => setEditFine(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Assigned Supervisory Officer</label>
                <input
                  type="text"
                  value={editOfficer}
                  onChange={(e) => setEditOfficer(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedViolation(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-500 font-bold text-white rounded-lg"
                >
                  Update Violation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
