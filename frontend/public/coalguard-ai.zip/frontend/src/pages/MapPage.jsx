import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import {
  MapPin, AlertTriangle, ShieldCheck, Mountain, ExternalLink,
  Loader2, Sparkles
} from "lucide-react";
import { mineService } from "../services/api";
import RiskBadge from "../components/RiskBadge";

// Custom Leaflet DivIcon with pulsing risk status circles
const createRiskIcon = (riskLevel) => {
  let color = "#10B981"; // Low
  let pulseClass = "bg-emerald-500";
  if (riskLevel === "CRITICAL") {
    color = "#EF4444";
    pulseClass = "bg-red-500 animate-ping";
  } else if (riskLevel === "HIGH") {
    color = "#F97316";
    pulseClass = "bg-orange-500";
  } else if (riskLevel === "MEDIUM") {
    color = "#F59E0B";
    pulseClass = "bg-amber-500";
  }

  return L.divIcon({
    className: "custom-leaflet-marker",
    html: `
      <div style="position: relative; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;">
        <span style="position: absolute; width: 24px; height: 24px; border-radius: 9999px; opacity: 0.75;" class="${pulseClass}"></span>
        <span style="position: relative; width: 18px; height: 18px; border-radius: 9999px; background-color: ${color}; border: 2px solid white; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.5);"></span>
      </div>
    `,
    iconSize: [28, 28],
    iconAnchor: [14, 14],
    popupAnchor: [0, -14],
  });
};

export default function MapPage() {
  const [mines, setMines] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    mineService.getAll({ limit: 50 })
      .then((res) => setMines(res.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  // Center on Indian coal belt (Dhanbad / Jharkhand / Central India)
  const defaultCenter = [22.8, 83.5];
  const defaultZoom = 6;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <MapPin className="w-6 h-6 text-emerald-400" />
              National Interactive Coal Mining GIS Geospatial Map
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold text-amber-300 bg-amber-950/60 border border-amber-800 rounded">
              OPENSTREETMAP
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Geospatial surveillance across major coalfields (Jharia, Korba, Singrauli, Talcher, Raniganj, Ib Valley).
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-950 border border-slate-800">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="text-slate-300">Low</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-950 border border-slate-800">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <span className="text-slate-300">Med</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-950 border border-slate-800">
            <span className="w-2.5 h-2.5 rounded-full bg-orange-500" />
            <span className="text-slate-300">High</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-950 border border-slate-800">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
            <span className="text-slate-300">Critical</span>
          </div>
        </div>
      </div>

      {/* Demonstration Data Disclaimer Banner (Section 20) */}
      <div className="p-3 rounded-xl bg-slate-900 border border-amber-800/50 text-xs text-amber-300 flex items-center gap-2">
        <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
        <span>DEMONSTRATION GEOSPATIAL DATA · Coordinates plotted for Smart India Hackathon 2026 simulation.</span>
      </div>

      {/* Map Canvas */}
      <div className="rounded-2xl border border-slate-800 overflow-hidden shadow-2xl h-[600px] w-full relative">
        {loading ? (
          <div className="h-full w-full flex items-center justify-center bg-slate-950 text-slate-400 text-xs gap-2">
            <Loader2 className="w-5 h-5 animate-spin text-emerald-400" />
            <span>Loading Geospatial Map Layers...</span>
          </div>
        ) : (
          <MapContainer
            center={defaultCenter}
            zoom={defaultZoom}
            scrollWheelZoom={true}
            className="w-full h-full"
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />

            {mines.map((mine) => (
              <Marker
                key={mine.id}
                position={[mine.latitude, mine.longitude]}
                icon={createRiskIcon(mine.risk_level)}
              >
                <Popup className="custom-popup">
                  <div className="p-2 space-y-2 text-slate-100 min-w-[220px]">
                    <div className="border-b border-slate-700 pb-1.5">
                      <h4 className="font-bold text-sm text-white">{mine.name}</h4>
                      <p className="text-[10px] text-slate-400">{mine.district}, {mine.state}</p>
                    </div>

                    <div className="space-y-1 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Risk Assessment:</span>
                        <RiskBadge level={mine.risk_level} score={mine.risk_score} size="sm" />
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Compliance:</span>
                        <span className="font-bold font-mono text-emerald-400">{mine.compliance_score}%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Open Violations:</span>
                        <span className="font-bold font-mono text-orange-400">{mine.open_violations_count}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Last Inspected:</span>
                        <span className="font-mono text-[10px] text-slate-300">
                          {mine.last_inspection ? new Date(mine.last_inspection).toLocaleDateString() : "Recent"}
                        </span>
                      </div>
                    </div>
                  </div>
                </Popup>
              </Marker>
            ))}
          </MapContainer>
        )}
      </div>
    </div>
  );
}
