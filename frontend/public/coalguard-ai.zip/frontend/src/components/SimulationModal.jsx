import React, { useState, useEffect } from "react";
import {
  Play, CheckCircle2, AlertTriangle, ArrowRight, ShieldAlert,
  FileCheck2, Activity, Cpu, RotateCcw, X, Loader2
} from "lucide-react";
import { simulationService } from "../services/api";

export default function SimulationModal({ isOpen, onClose, onComplete, initialMineId }) {
  const [isRunning, setIsRunning] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [simulationData, setSimulationData] = useState(null);
  const [error, setError] = useState(null);
  const [selectedStep, setSelectedStep] = useState(null);

  if (!isOpen) return null;

  const handleStartSimulation = async () => {
    setIsRunning(true);
    setError(null);
    setCurrentStepIndex(0);
    setSimulationData(null);
    setSelectedStep(null);

    try {
      const res = await simulationService.run(initialMineId || 1);
      const data = res.data;
      setSimulationData(data);

      // Animate through 14 steps sequentially for impressive visual demo
      for (let i = 0; i < data.steps.length; i++) {
        await new Promise((resolve) => setTimeout(resolve, 850));
        setCurrentStepIndex(i + 1);
        setSelectedStep(data.steps[i]);
      }
      setIsRunning(false);
      if (onComplete) onComplete();
    } catch (err) {
      console.error(err);
      setError("Simulation failed to execute. Ensure backend server is running.");
      setIsRunning(false);
    }
  };

  const handleResetBaseline = async () => {
    try {
      await simulationService.reset(initialMineId || 1);
      setSimulationData(null);
      setCurrentStepIndex(0);
      setSelectedStep(null);
      if (onComplete) onComplete();
    } catch (err) {
      console.error(err);
    }
  };

  const activeSteps = simulationData?.steps || [];
  const progressPercent = activeSteps.length > 0 ? (currentStepIndex / activeSteps.length) * 100 : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 text-white shadow-lg shadow-rose-900/30">
              <Cpu className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-wide">
                  AI Risk & Compliance Closed-Loop Simulation
                </h2>
                <span className="px-2 py-0.5 text-[10px] font-semibold tracking-wider text-amber-300 bg-amber-950/60 border border-amber-800/60 rounded">
                  SIH 2026 LIVE DEMO
                </span>
              </div>
              <p className="text-xs text-slate-400">
                14-Step End-to-End Governance: Sensor Surge → Anomaly ML → Risk Escalation → Alert → Inspection → Remediation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-800 h-1.5 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500 transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: 14 Steps List */}
          <div className="lg:col-span-7 space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                Workflow Trace ({currentStepIndex}/{simulationData?.steps?.length || 14} Executed)
              </span>
              {simulationData && (
                <span className="text-xs font-medium text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> ID: {simulationData.simulation_id}
                </span>
              )}
            </div>

            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {activeSteps.length === 0 ? (
                <div className="p-8 text-center border border-dashed border-slate-800 rounded-xl bg-slate-950/40">
                  <Activity className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <p className="text-sm font-medium text-slate-300">Ready to initiate AI Governance simulation</p>
                  <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                    Click "Run AI Simulation" to inject a real-time methane gas anomaly and observe the autonomous multi-role compliance pipeline.
                  </p>
                </div>
              ) : (
                activeSteps.map((step, idx) => {
                  const isDone = idx < currentStepIndex;
                  const isCurrent = idx === currentStepIndex - 1 && isRunning;
                  const isSelected = selectedStep?.step_number === step.step_number;

                  return (
                    <div
                      key={step.step_number}
                      onClick={() => setSelectedStep(step)}
                      className={`p-3 rounded-xl border cursor-pointer transition flex items-start gap-3 ${
                        isSelected
                          ? "bg-slate-800/90 border-indigo-500/60 shadow-lg shadow-indigo-950/30"
                          : isDone
                          ? "bg-slate-950/50 border-slate-800 hover:border-slate-700"
                          : "bg-slate-950/20 border-slate-900 opacity-40"
                      }`}
                    >
                      <div className="mt-0.5">
                        {isCurrent ? (
                          <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />
                        ) : isDone ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <div className="w-4 h-4 rounded-full border border-slate-700 text-[10px] flex items-center justify-center text-slate-500 font-mono">
                            {step.step_number}
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-semibold text-slate-200">
                            {step.step_number}. {step.title}
                          </h4>
                          {idx === 2 && (
                            <span className="text-[10px] bg-purple-900/60 text-purple-300 px-1.5 py-0.5 rounded border border-purple-800/60 font-mono">
                              ML
                            </span>
                          )}
                          {idx === 4 && (
                            <span className="text-[10px] bg-red-900/60 text-red-300 px-1.5 py-0.5 rounded border border-red-800/60 font-mono">
                              CRITICAL
                            </span>
                          )}
                          {idx === 13 && (
                            <span className="text-[10px] bg-emerald-900/60 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-800/60 font-mono">
                              LOW RISK
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                          {step.description}
                        </p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Right Column: Step Inspector & Action Cards */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2 mb-3">
                <FileCheck2 className="w-4 h-4 text-indigo-400" />
                Step Details & Telemetry Inspection
              </h3>

              {selectedStep ? (
                <div className="space-y-3">
                  <div className="p-3 rounded-lg bg-slate-900/80 border border-slate-800/80">
                    <span className="text-xs text-indigo-400 font-medium">
                      Step {selectedStep.step_number}
                    </span>
                    <h4 className="text-sm font-bold text-white mt-0.5">
                      {selectedStep.title}
                    </h4>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                      {selectedStep.description}
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800/60">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                      Recorded State Payload:
                    </span>
                    <pre className="mt-1 text-[11px] font-mono text-emerald-400 overflow-x-auto p-2 bg-slate-950 rounded border border-slate-800 max-h-48">
                      {JSON.stringify(selectedStep.details, null, 2)}
                    </pre>
                  </div>
                </div>
              ) : (
                <div className="py-12 text-center text-slate-500 text-xs">
                  Run the simulation or select a step from the left to inspect its telemetry and decision record.
                </div>
              )}
            </div>

            {error && (
              <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-xs text-red-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-3">
              <button
                disabled={isRunning}
                onClick={handleStartSimulation}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-semibold text-sm text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 shadow-lg shadow-emerald-950/50 disabled:opacity-50 transition"
              >
                {isRunning ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Simulating AI Closed-Loop (Step {currentStepIndex}/14)...
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    RUN AI RISK SIMULATION
                  </>
                )}
              </button>

              <div className="flex items-center gap-2">
                <button
                  disabled={isRunning}
                  onClick={handleResetBaseline}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Reset Baseline State
                </button>
                <button
                  onClick={onClose}
                  className="py-2 px-4 rounded-lg text-xs font-medium text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 transition"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
