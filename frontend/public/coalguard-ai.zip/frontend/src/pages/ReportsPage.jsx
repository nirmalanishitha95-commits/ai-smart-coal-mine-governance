import React, { useState, useEffect } from "react";
import {
  FileText, Download, Printer, Filter, Calendar, ShieldCheck,
  Building, AlertTriangle, Loader2
} from "lucide-react";
import { reportService, mineService } from "../services/api";

export default function ReportsPage() {
  const [reportType, setReportType] = useState("compliance");
  const [mines, setMines] = useState([]);
  const [selectedMineId, setSelectedMineId] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(true);

  const reportTypes = [
    { id: "compliance", label: "Statutory Compliance Report" },
    { id: "risk", label: "Mine Risk Assessment Report" },
    { id: "violation", label: "Violations & Penalty Report" },
    { id: "inspection", label: "Inspections Summary Report" },
    { id: "corrective_action", label: "Corrective Action (CAPA) Report" },
  ];

  const fetchReport = () => {
    setLoading(true);
    reportService.getSummary({
      report_type: reportType,
      mine_id: selectedMineId || undefined,
      status: statusFilter || undefined
    })
      .then((res) => setReportData(res.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    mineService.getAll({ limit: 50 }).then((res) => setMines(res.data));
  }, []);

  useEffect(() => {
    fetchReport();
  }, [reportType, selectedMineId, statusFilter]);

  const handlePrint = () => {
    window.print();
  };

  const csvDownloadUrl = reportService.getExportCsvUrl(reportType, selectedMineId, statusFilter);

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <FileText className="w-6 h-6 text-emerald-400" />
            Statutory Regulatory Reports & Data Exports
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Generate printable audit reports, DGMS inspection filings, and structured CSV extracts.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <a
            href={csvDownloadUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-200 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 transition"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export CSV</span>
          </a>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-950/40 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Official Report</span>
          </button>
        </div>
      </div>

      {/* Report Controls & Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Select Report Type</label>
          <select
            value={reportType}
            onChange={(e) => setReportType(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            {reportTypes.map((t) => (
              <option key={t.id} value={t.id}>{t.label}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Target Mine</label>
          <select
            value={selectedMineId}
            onChange={(e) => setSelectedMineId(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Mines (Consolidated)</option>
            {mines.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Status Filter</label>
          <input
            type="text"
            placeholder="e.g. COMPLIANT, OPEN, CRITICAL..."
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Official Formatted Printable Document Container */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900 p-6 sm:p-8 space-y-6 shadow-2xl print:bg-white print:text-black print:border-none print:shadow-none">
        {/* Document Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-800 gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider print:text-emerald-700">
              Government of India · Ministry of Coal · DGMS
            </span>
            <h2 className="text-xl font-bold text-white print:text-black">
              {reportTypes.find((t) => t.id === reportType)?.label}
            </h2>
            <p className="text-xs text-slate-400 print:text-slate-600">
              Generated via CoalGuard AI Enterprise Governance System (Smart India Hackathon 2026)
            </p>
          </div>

          <div className="text-left sm:text-right text-xs text-slate-400 space-y-0.5 print:text-slate-600">
            <div>Timestamp: <strong className="font-mono text-slate-200 print:text-black">{reportData?.generated_at}</strong></div>
            <div>Total Records: <strong className="font-mono text-slate-200 print:text-black">{reportData?.total_records}</strong></div>
          </div>
        </div>

        {/* Records Table */}
        {loading ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-400" />
            Compiling report datasets...
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider print:bg-slate-100 print:text-black">
                <tr>
                  {(reportData?.columns || []).map((col, idx) => (
                    <th key={idx} className="py-3 px-3.5">{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300 print:text-black print:divide-slate-200">
                {(reportData?.rows || []).length === 0 ? (
                  <tr>
                    <td colSpan={(reportData?.columns || []).length || 5} className="py-8 text-center text-slate-500">
                      No records found matching filters.
                    </td>
                  </tr>
                ) : (
                  (reportData?.rows || []).map((row, i) => {
                    const values = Object.entries(row).filter(([k]) => k !== "id").map(([, v]) => v);
                    return (
                      <tr key={i} className="hover:bg-slate-800/30 print:hover:bg-transparent">
                        {values.map((val, cellIdx) => (
                          <td key={cellIdx} className="py-3 px-3.5 font-medium">
                            {typeof val === "string" && val.includes("COMPLIANT") ? (
                              <span className="font-bold text-emerald-400 print:text-emerald-700">{val}</span>
                            ) : typeof val === "string" && (val.includes("CRITICAL") || val.includes("HIGH")) ? (
                              <span className="font-bold text-red-400 print:text-red-700">{val}</span>
                            ) : (
                              val
                            )}
                          </td>
                        ))}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* Statutory Sign-off Box */}
        <div className="pt-8 border-t border-slate-800/80 grid grid-cols-2 text-xs text-slate-400 print:text-slate-600">
          <div>
            <p className="font-semibold text-slate-300 print:text-black">Prepared By:</p>
            <p className="mt-1">CoalGuard AI Digital Compliance Audit Engine</p>
          </div>
          <div className="text-right">
            <p className="font-semibold text-slate-300 print:text-black">Statutory Verification:</p>
            <p className="mt-1">Directorate General of Mines Safety (DGMS)</p>
          </div>
        </div>
      </div>
    </div>
  );
}
