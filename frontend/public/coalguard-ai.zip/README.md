# CoalGuard AI

### AI-Based Smart Governance and Compliance Monitoring System for Coal Mines
> **Smart India Hackathon 2026**  
> *“AI-powered compliance, safety and environmental monitoring for smarter and safer coal mining.”*

---

## 📌 Project Overview

**CoalGuard AI** is an enterprise-grade digital governance platform engineered for the **Ministry of Coal**, the **Directorate General of Mines Safety (DGMS)**, and mine operators. It bridges statutory compliance, real-time IoT multi-gas telemetry, and machine learning surveillance to proactively prevent disasters, track regulatory violations, and streamline remedial action plans.

> [!NOTE]
> **AI-Assisted Risk Assessment**: In accordance with regulatory standards, all AI outputs serve as explainable decision-support for authorized inspectors and officers. Final legal compliance determinations remain under statutory officer purview.

---

## 🛠 Technology Stack

### Frontend
* **Core**: React.js 19 + Vite 8
* **Styling**: Tailwind CSS v4 + Lucide React Icons
* **Routing**: React Router v7
* **Data Visualization**: Recharts (6 dynamic charts: Line, Donut, Bar, Area)
* **GIS Mapping**: Leaflet + OpenStreetMap + React Leaflet
* **HTTP Client**: Axios with JWT Bearer Interceptors

### Backend & AI
* **Framework**: Python 3.11 / 3.14 + FastAPI
* **ORM & Database**: SQLAlchemy 2.0 + MySQL 8.0 (with automatic resilient local SQLite fallback for out-of-the-box offline evaluation)
* **Security & Auth**: JWT (PyJWT) + PBKDF2 HMAC SHA-256 (100,000 iterations)
* **Machine Learning**: Scikit-Learn Isolation Forest (100 estimators)
* **Risk Engine**: Explainable rule-based scoring (0–100 scale, factor breakdowns)

### Deployment & DevOps
* **Containerization**: Docker & Docker Compose
* **Frontend Target**: Vercel
* **Backend Target**: Render
* **Database Target**: Cloud MySQL (Aiven / PlanetScale / AWS RDS)

---

## 🚀 Quick Start Guide

### Option 1: Docker Compose (Recommended for Full Production Stack)
Ensure Docker is installed and running, then execute:
```bash
docker compose up --build
```
* **Frontend**: `http://localhost:5173` or `http://localhost:80`
* **FastAPI Backend & Swagger Docs**: `http://localhost:8000/docs`
* **MySQL Database**: `localhost:3306`

---

### Option 2: Local Development Setup

#### 1. Backend Setup
```bash
cd backend

# Create and activate virtual environment
python -m venv venv
# Windows:
.\venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run backend (auto-seeds database on startup)
uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```
API Documentation will be live at: `http://localhost:8000/docs`

#### 2. Frontend Setup
```bash
cd frontend

# Install npm packages
npm install

# Start development server
npm run dev
```
Open your browser at `http://localhost:5173`.

---

## 🔑 Demo User Credentials

The database is pre-seeded with 4 distinct roles for comprehensive SIH evaluation:

| Role | Designation | Email | Password | Primary Capabilities |
| :--- | :--- | :--- | :--- | :--- |
| **SUPER ADMIN** | Coal Controller of India | `admin@coalguard.gov.in` | `Admin@123` | Full system access, all mines, rules, audit logs |
| **GOVT OFFICER** | Regional Mining Officer (DGMS) | `officer@coalguard.gov.in` | `Officer@123` | Inspections, violations, verification sign-off |
| **MINE MANAGER** | General Manager (Operations) | `manager@coalguard.gov.in` | `Manager@123` | Mine telemetry, upload remediation evidence |
| **INSPECTOR** | Statutory Safety Auditor | `inspector@coalguard.gov.in` | `Inspector@123` | Conduct inspections, 7-question digital checklist |

*(A quick 1-click role switcher is built directly into the top navigation bar for seamless demo navigation).*

---

## 🔄 The 14-Step AI Closed-Loop Workflow (SIH Presentation)

Click the **“RUN AI RISK SIMULATION”** button from the top navigation bar or the dashboard to observe the autonomous multi-role governance loop:

```text
1. Baseline Telemetry Ingestion (Methane 0.42%, CO 9.5 ppm, Dust 48 µg/m³)
   ↓
2. Hazard Surge Simulated (Methane spikes to 3.75%, CO to 64 ppm in Shaft 4)
   ↓
3. Scikit-Learn Isolation Forest classifies observation as CRITICAL ANOMALY
   ↓
4. AI Risk Engine recalculates composite mine score (Spikes from 42.0 to 84.0)
   ↓
5. Mine Status escalated to CRITICAL on National Command Board
   ↓
6. Priority 1 Alert generated & broadcasted to District Mining Officer
   ↓
7. Government Officer reviews alert telemetry and acknowledges triage
   ↓
8. Emergency Safety Inspection dispatched under statutory order
   ↓
9. Inspector completes digital checklist (Fails Q3: Ventilation Operational)
   ↓
10. Formal Regulatory Violation issued under Coal Mines Regulations Sec 153
   ↓
11. Mandatory Corrective Action Plan (CAPA) assigned with 48-hour SLA
   ↓
12. Mine Manager submits flameproof equipment certificate and airflow logs
   ↓
13. Government Officer conducts digital verification & approves sign-off
   ↓
14. Governance Loop Closed: Risk drops to 22.0 (LOW), compliance restored, audit log committed
```

---

## 🌐 Cloud Deployment Instructions

### Frontend on Vercel
1. Link your GitHub repository to Vercel.
2. Set **Root Directory** to `frontend`.
3. Set **Build Command** to `npm run build` and **Output Directory** to `dist`.
4. Configure Environment Variable:
   ```env
   VITE_API_URL=https://your-render-backend.onrender.com/api
   ```
5. Deploy!

### Backend on Render
1. Create a new **Web Service** on Render pointing to your repository.
2. Set **Root Directory** to `backend`.
3. Set **Runtime** to `Python 3`.
4. Set **Build Command** to `pip install -r requirements.txt`.
5. Set **Start Command** to `uvicorn backend.main:app --host 0.0.0.0 --port $PORT`.
6. Add Environment Variables:
   ```env
   DATABASE_URL=mysql+pymysql://<user>:<password>@<host>:3306/coalguard_ai
   JWT_SECRET=coalguard-production-super-secret-key-sih-2026-secure
   CORS_ORIGINS=https://your-vercel-app.vercel.app
   ```
7. Deploy!

---

## 📂 Project Structure

```text
coalguard-ai/
├── backend/
│   ├── app/
│   │   ├── ai/
│   │   │   ├── anomaly_detector.py      # Isolation Forest Anomaly ML
│   │   │   ├── risk_engine.py           # Explainable Rule-Based Scoring
│   │   │   └── simulation_service.py    # 14-Step Workflow Automation
│   │   ├── api/                         # 13 REST API Endpoint Modules
│   │   ├── database/                    # SQLAlchemy Engine & Sessions
│   │   ├── models/                      # 17 Normalized Database Models
│   │   ├── schemas/                     # Pydantic Request/Response Models
│   │   └── services/                    # Auth, Audit, & DB Seed Services
│   ├── Dockerfile
│   ├── main.py                          # FastAPI App Entrypoint
│   └── requirements.txt
├── database/
│   ├── schema.sql                       # MySQL 8.0 DDL Script
│   └── seed.sql                         # MySQL 8.0 DML Seed Script
├── docs/
│   └── ARCHITECTURE.md                  # Detailed Architecture & Sequence Diagrams
├── frontend/
│   ├── src/
│   │   ├── components/                  # Navbar, Sidebar, Badges, Modals
│   │   ├── context/                     # AuthContext & Demo Role Switcher
│   │   ├── layouts/                     # DashboardLayout
│   │   ├── pages/                       # 13 Complete Working Pages
│   │   ├── services/                    # Axios API Client
│   │   ├── App.jsx                      # Routing
│   │   ├── index.css                    # Tailwind CSS Theme
│   │   └── main.jsx
│   ├── Dockerfile
│   ├── nginx.conf
│   └── package.json
├── docker-compose.yml
└── README.md
```

---

## 🏆 Smart India Hackathon 2026 Highlights

* **100% Real Working System**: Connected backend APIs, normalized database, real JWT authentication, and interactive front-end.
* **Explainable AI**: Transparent factor breakdown for every risk score (+25 Gas Anomaly, +20 Violations, +15 Overdue Actions).
* **Live Telemetry ML**: Real Isolation Forest model trained on multi-sensor mining baseline data.
* **Digital 7-Question Checklist**: Automatic violation generation when statutory safety checks fail.
* **Resilient Infrastructure**: Connects out of the box with zero setup hurdles.
