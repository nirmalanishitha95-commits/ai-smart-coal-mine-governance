import React, { useState, useEffect } from "react";
import {
  Bell, AlertTriangle, CheckCircle2, ShieldAlert, Check, X,
  Search, Filter, Clock, Loader2
} from "lucide-react";
import { alertService, mineService } from "../services/api";
import RiskBadge from "../components/RiskBadge";

export default function AlertsPage() {
  const [alerts, setAlerts] = useState([]);
  const [mines, setMines] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [severityFilter, setSeverityFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [mineFilter, setMineFilter] = useState("");

  const fetchData = () => {
    setLoading(true);
    Promise.all([
      alertService.getAll({
        severity: severityFilter || undefined,
        status: statusFilter || undefined,
        mine_id: mineFilter || undefined
      }),
      mineService.getAll({ limit: 50 })
    ])
      .then(([aRes, mRes]) => {
        setAlerts(aRes.data);
        setMines(mRes.data);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchData();
  }, [severityFilter, statusFilter, mineFilter]);

  const handleAcknowledge = async (id) => {
    try {
      await alertService.acknowledge(id);
      fetchData();
    } catch (err) {
      alert("Failed to acknowledge alert.");
    }
  };

  const handleResolve = async (id) => {
    try {
      await alertService.resolve(id);
      fetchData();
    } catch (err) {
      alert("Failed to resolve alert.");
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Bell className="w-6 h-6 text-rose-400" />
            Central Regulatory Alert & Early-Warning Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time critical telemetry alerts, compliance deadlines, and automated hazard triggers.
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Filter by Severity</label>
          <select
            value={severityFilter}
            onChange={(e) => setSeverityFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Severities</option>
            <option value="CRITICAL">Critical (Immediate Triage)</option>
            <option value="HIGH">High</option>
            <option value="MEDIUM">Medium</option>
            <option value="LOW">Low</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Filter by Status</label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Statuses</option>
            <option value="UNREAD">Unread</option>
            <option value="READ">Read</option>
            <option value="ACKNOWLEDGED">Acknowledged</option>
            <option value="RESOLVED">Resolved</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Filter by Mine</label>
          <select
            value={mineFilter}
            onChange={(e) => setMineFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Mines</option>
            {mines.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Alerts Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Severity</th>
                <th className="py-3 px-3">Mine Location</th>
                <th className="py-3 px-3">Alert Trigger Type</th>
                <th className="py-3 px-3">Notification Message</th>
                <th className="py-3 px-3">Timestamp</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-rose-400" />
                    <span>Loading active alerts...</span>
                  </td>
                </tr>
              ) : alerts.length === 0 ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-500">
                    No alerts found for current criteria.
                  </td>
                </tr>
              ) : (
                alerts.map((a) => {
                  const isCritical = a.severity === "CRITICAL";

                  return (
                    <tr
                      key={a.id}
                      className={`hover:bg-slate-800/40 transition ${
                        isCritical && a.status !== "RESOLVED" ? "bg-red-950/15" : ""
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <RiskBadge level={a.severity} showScore={false} size="sm" />
                      </td>
                      <td className="py-3.5 px-3 font-semibold text-white">
                        {a.mine_name}
                      </td>
                      <td className="py-3.5 px-3">
                        <span className="font-semibold text-slate-300">{a.alert_type}</span>
                      </td>
                      <td className="py-3.5 px-3 max-w-md truncate text-slate-300">
                        {a.message}
                      </td>
                      <td className="py-3.5 px-3 font-mono text-slate-400 text-[11px]">
                        {new Date(a.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                      <td className="py-3.5 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          a.status === "RESOLVED"
                            ? "bg-emerald-950 text-emerald-400 border border-emerald-800"
                            : a.status === "ACKNOWLEDGED"
                            ? "bg-blue-950 text-blue-400 border border-blue-800"
                            : "bg-red-950 text-red-400 border border-red-800 animate-pulse"
                        }`}>
                          {a.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-3 text-right space-x-2">
                        {a.status !== "ACKNOWLEDGED" && a.status !== "RESOLVED" && (
                          <button
                            onClick={() => handleAcknowledge(a.id)}
                            className="px-2.5 py-1 rounded-lg text-xs font-semibold text-blue-300 hover:text-white bg-blue-950/80 hover:bg-blue-900 border border-blue-800 transition"
                          >
                            Acknowledge
                          </button>
                        )}
                        {a.status !== "RESOLVED" && (
                          <button
                            onClick={() => handleResolve(a.id)}
                            className="px-2.5 py-1 rounded-lg text-xs font-semibold text-emerald-300 hover:text-white bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800 transition"
                          >
                            Resolve
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
