import React, { useState, useEffect } from "react";
import {
  ClipboardCheck, Plus, CheckCircle2, XCircle, AlertTriangle,
  Calendar, User, FileText, ChevronRight, X, Loader2, Sparkles
} from "lucide-react";
import { inspectionService, mineService } from "../services/api";
import RiskBadge from "../components/RiskBadge";
import { useAuth } from "../context/AuthContext";

export default function InspectionsPage() {
  const { user, role } = useAuth();
  const [inspections, setInspections] = useState([]);
  const [mines, setMines] = useState([]);
  const [loading, setLoading] = useState(true);

  // Schedule Modal
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    mine_id: 1,
    inspection_type: "Routine",
    scheduled_date: new Date().toISOString().split("T")[0]
  });

  // Digital Checklist Modal (Section 17)
  const [activeInspection, setActiveInspection] = useState(null);
  const checklistQuestions = [
    "Is required safety equipment available?",
    "Are emergency exits maintained?",
    "Is ventilation operational?",
    "Is required documentation available?",
    "Are environmental controls functioning?",
    "Are worker safety measures followed?",
    "Is emergency response documentation available?"
  ];

  const [checklistAnswers, setChecklistAnswers] = useState({});
  const [overallFinding, setOverallFinding] = useState("");
  const [recommendations, setRecommendations] = useState("");

  const fetchData = () => {
    setLoading(true);
    Promise.all([
      inspectionService.getAll(),
      mineService.getAll({ limit: 50 })
    ])
      .then(([inspRes, minesRes]) => {
        setInspections(inspRes.data);
        setMines(minesRes.data);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenChecklist = (insp) => {
    setActiveInspection(insp);
    // Initialize default YES for all 7 questions
    const initial = {};
    checklistQuestions.forEach((q) => {
      initial[q] = {
        answer: "YES",
        finding_description: "",
        severity: "LOW",
        evidence: "",
        corrective_action_required: false
      };
    });
    setChecklistAnswers(initial);
    setOverallFinding("");
    setRecommendations("");
  };

  const handleAnswerChange = (question, answer) => {
    setChecklistAnswers((prev) => ({
      ...prev,
      [question]: {
        ...prev[question],
        answer,
        corrective_action_required: answer === "NO"
      }
    }));
  };

  const handleFindingDetailChange = (question, field, value) => {
    setChecklistAnswers((prev) => ({
      ...prev,
      [question]: {
        ...prev[question],
        [field]: value
      }
    }));
  };

  const handleSubmitChecklist = async (e) => {
    e.preventDefault();
    if (!activeInspection) return;

    const items = Object.entries(checklistAnswers).map(([item, data]) => ({
      checklist_item: item,
      answer: data.answer,
      finding_description: data.answer === "NO" ? data.finding_description : null,
      severity: data.severity,
      evidence: data.evidence || null,
      corrective_action_required: data.answer === "NO"
    }));

    try {
      await inspectionService.submitChecklist(activeInspection.id, {
        items,
        overall_finding: overallFinding || "Inspection completed according to statutory checklist.",
        recommendations: recommendations || "Maintain continuous monitoring.",
        status: "COMPLETED"
      });
      setActiveInspection(null);
      fetchData();
    } catch (err) {
      alert("Failed to submit inspection checklist.");
    }
  };

  const handleScheduleSubmit = async (e) => {
    e.preventDefault();
    try {
      await inspectionService.schedule({
        mine_id: parseInt(scheduleForm.mine_id),
        inspection_type: scheduleForm.inspection_type,
        scheduled_date: new Date(scheduleForm.scheduled_date).toISOString()
      });
      setShowScheduleModal(false);
      fetchData();
    } catch (err) {
      alert("Failed to schedule inspection.");
    }
  };

  const isInspectorOrOfficer = role === "INSPECTOR" || role === "GOVERNMENT_OFFICER" || role === "SUPER_ADMIN";

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <ClipboardCheck className="w-6 h-6 text-emerald-400" />
            Statutory Inspections & Digital Audit Checklists
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Conduct DGMS safety audits, fill interactive dynamic checklists, and generate instant violations.
          </p>
        </div>

        {isInspectorOrOfficer && (
          <button
            onClick={() => setShowScheduleModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-950/40 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Schedule New Inspection</span>
          </button>
        )}
      </div>

      {/* Inspections Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Inspection ID</th>
                <th className="py-3 px-3">Mine Block</th>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Inspector</th>
                <th className="py-3 px-3">Scheduled Date</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3 text-right">Audit Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-400" />
                    <span>Loading inspections...</span>
                  </td>
                </tr>
              ) : inspections.length === 0 ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-500">
                    No inspections recorded yet.
                  </td>
                </tr>
              ) : (
                inspections.map((insp) => (
                  <tr key={insp.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4 font-mono font-bold text-white">
                      INSP-{insp.id}
                    </td>
                    <td className="py-3.5 px-3 font-semibold text-white">
                      {insp.mine_name}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                        {insp.inspection_type}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-slate-300">
                      {insp.inspector_name || "Statutory Inspector"}
                    </td>
                    <td className="py-3.5 px-3 font-mono text-[11px] text-slate-400">
                      {new Date(insp.scheduled_date).toLocaleDateString()}
                    </td>
                    <td className="py-3.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        insp.status === "COMPLETED"
                          ? "bg-emerald-950 text-emerald-400 border border-emerald-800"
                          : insp.status === "IN PROGRESS"
                          ? "bg-amber-950 text-amber-400 border border-amber-800"
                          : "bg-blue-950 text-blue-400 border border-blue-800"
                      }`}>
                        {insp.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      {insp.status !== "COMPLETED" ? (
                        <button
                          onClick={() => handleOpenChecklist(insp)}
                          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-semibold text-emerald-300 hover:text-white bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-800 transition"
                        >
                          <span>Conduct Audit</span>
                          <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-500 font-mono">
                          {insp.findings.length} Items Logged
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Digital Inspection Checklist Modal (Section 17) */}
      {activeInspection && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-3xl max-h-[90vh] overflow-hidden flex flex-col rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-950 border border-emerald-800 flex items-center justify-center text-emerald-400">
                  <ClipboardCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Digital Statutory Checklist — {activeInspection.mine_name}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Inspection #{activeInspection.id} · Type: {activeInspection.inspection_type}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActiveInspection(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Checklist Form Body */}
            <form onSubmit={handleSubmitChecklist} className="flex-1 overflow-y-auto p-6 space-y-5 text-xs">
              <div className="space-y-4">
                {checklistQuestions.map((q, idx) => {
                  const state = checklistAnswers[q] || { answer: "YES" };
                  const isNo = state.answer === "NO";

                  return (
                    <div
                      key={idx}
                      className={`p-4 rounded-xl border transition ${
                        isNo
                          ? "bg-red-950/20 border-red-800/80"
                          : "bg-slate-950/60 border-slate-800"
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <span className="font-semibold text-slate-200 text-xs">
                          {idx + 1}. {q}
                        </span>

                        <div className="flex items-center gap-2">
                          {["YES", "NO", "NOT APPLICABLE"].map((opt) => (
                            <button
                              key={opt}
                              type="button"
                              onClick={() => handleAnswerChange(q, opt)}
                              className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                                state.answer === opt
                                  ? opt === "YES"
                                    ? "bg-emerald-600 text-white"
                                    : opt === "NO"
                                    ? "bg-red-600 text-white"
                                    : "bg-slate-700 text-white"
                                  : "bg-slate-800 text-slate-400 hover:text-white"
                              }`}
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* If NO is selected: Dynamic Finding & Corrective Action Fields (Section 17) */}
                      {isNo && (
                        <div className="mt-3 pt-3 border-t border-red-900/40 space-y-3 animate-fadeIn">
                          <div className="flex items-center gap-2 text-red-300 font-semibold text-[11px]">
                            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                            <span>Non-Conformance Detected: Automatic Violation & Corrective Action will be generated.</span>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div>
                              <label className="block text-slate-300 font-semibold mb-1">
                                Finding Description *
                              </label>
                              <input
                                required
                                type="text"
                                placeholder="Describe non-compliance (e.g. Auxiliary blower tripped)..."
                                value={state.finding_description || ""}
                                onChange={(e) => handleFindingDetailChange(q, "finding_description", e.target.value)}
                                className="w-full py-1.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-200"
                              />
                            </div>
                            <div>
                              <label className="block text-slate-300 font-semibold mb-1">
                                Severity Rating *
                              </label>
                              <select
                                value={state.severity || "HIGH"}
                                onChange={(e) => handleFindingDetailChange(q, "severity", e.target.value)}
                                className="w-full py-1.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-200"
                              >
                                <option value="LOW">LOW</option>
                                <option value="MEDIUM">MEDIUM</option>
                                <option value="HIGH">HIGH</option>
                                <option value="CRITICAL">CRITICAL</option>
                              </select>
                            </div>
                          </div>

                          <div>
                            <label className="block text-slate-300 font-semibold mb-1">
                              Evidence Upload Reference
                            </label>
                            <input
                              type="text"
                              placeholder="e.g. photo_fan_tripped_junction4.jpg"
                              value={state.evidence || ""}
                              onChange={(e) => handleFindingDetailChange(q, "evidence", e.target.value)}
                              className="w-full py-1.5 px-3 bg-slate-900 border border-slate-700 rounded-lg text-slate-200"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Overall Findings & Recommendations */}
              <div className="space-y-3 pt-3 border-t border-slate-800">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Overall Inspection Finding</label>
                  <textarea
                    rows={2}
                    value={overallFinding}
                    onChange={(e) => setOverallFinding(e.target.value)}
                    placeholder="Summary of general safety and environmental conditions observed..."
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Statutory Recommendations</label>
                  <textarea
                    rows={2}
                    value={recommendations}
                    onChange={(e) => setRecommendations(e.target.value)}
                    placeholder="Directives for mine management..."
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  />
                </div>
              </div>

              {/* Footer Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setActiveInspection(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-lg shadow-lg shadow-emerald-950/50"
                >
                  Submit Final Inspection Audit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Schedule Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Schedule Statutory Mine Inspection</h3>
              <button onClick={() => setShowScheduleModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleScheduleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Select Target Mine</label>
                <select
                  value={scheduleForm.mine_id}
                  onChange={(e) => setScheduleForm({ ...scheduleForm, mine_id: e.target.value })}
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                >
                  {mines.map((m) => (
                    <option key={m.id} value={m.id}>{m.name} ({m.code})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Inspection Type</label>
                <select
                  value={scheduleForm.inspection_type}
                  onChange={(e) => setScheduleForm({ ...scheduleForm, inspection_type: e.target.value })}
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                >
                  <option value="Routine">Routine Audit</option>
                  <option value="Safety">Safety & Ventilation Audit</option>
                  <option value="Environmental">Environmental Effluent Audit</option>
                  <option value="Special">Special Investigation</option>
                  <option value="Follow-up">Follow-up Verification</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Scheduled Date</label>
                <input
                  required
                  type="date"
                  value={scheduleForm.scheduled_date}
                  onChange={(e) => setScheduleForm({ ...scheduleForm, scheduled_date: e.target.value })}
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowScheduleModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 font-bold text-white rounded-lg"
                >
                  Confirm Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
