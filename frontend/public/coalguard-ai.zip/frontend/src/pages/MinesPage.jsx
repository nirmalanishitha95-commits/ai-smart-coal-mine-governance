import React, { useState, useEffect } from "react";
import {
  Mountain, Search, Filter, Plus, ArrowUpDown, Eye, Edit2, Trash2,
  X, AlertTriangle, ShieldCheck, CheckCircle2, TrendingUp, Sparkles, Loader2
} from "lucide-react";
import { mineService } from "../services/api";
import RiskBadge from "../components/RiskBadge";
import { useAuth } from "../context/AuthContext";

export default function MinesPage() {
  const { role } = useAuth();
  const [mines, setMines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [riskFilter, setRiskFilter] = useState("");
  const [typeFilter, setTypeFilter] = useState("");
  const [sortBy, setSortBy] = useState("risk_score");
  const [order, setOrder] = useState("desc");

  // Modals state
  const [selectedRiskMine, setSelectedRiskMine] = useState(null);
  const [riskData, setRiskData] = useState(null);
  const [riskLoading, setRiskLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMineForm, setNewMineForm] = useState({
    name: "", code: "", location: "", district: "", state: "",
    mine_type: "Opencast", production_capacity: 2.5,
    operational_status: "Active", latitude: 23.75, longitude: 86.42
  });

  const fetchMines = () => {
    setLoading(true);
    mineService.getAll({
      search: search || undefined,
      risk_level: riskFilter || undefined,
      mine_type: typeFilter || undefined,
      sort_by: sortBy,
      order: order
    })
      .then((res) => setMines(res.data))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchMines();
  }, [search, riskFilter, typeFilter, sortBy, order]);

  // Open AI Risk Explanation Modal
  const handleOpenRisk = (mine) => {
    setSelectedRiskMine(mine);
    setRiskLoading(true);
    mineService.getRisk(mine.id)
      .then((res) => setRiskData(res.data))
      .catch((err) => console.error(err))
      .finally(() => setRiskLoading(false));
  };

  const handleCreateMine = async (e) => {
    e.preventDefault();
    try {
      await mineService.create(newMineForm);
      setShowAddModal(false);
      fetchMines();
    } catch (err) {
      alert("Failed to create mine. Check code uniqueness.");
    }
  };

  const isSuperAdmin = role === "SUPER_ADMIN" || role === "GOVERNMENT_OFFICER";

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <Mountain className="w-6 h-6 text-emerald-400" />
            Coal Mine Surveillance & Fleet Directory
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Statutory registry of underground, opencast, and mixed coal mining blocks across India.
          </p>
        </div>

        {isSuperAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-md shadow-emerald-950/40 transition"
          >
            <Plus className="w-4 h-4" />
            <span>Register New Mine</span>
          </button>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div className="sm:col-span-4 relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
          <input
            type="text"
            placeholder="Search by mine name, code, district..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        <div className="sm:col-span-3">
          <select
            value={riskFilter}
            onChange={(e) => setRiskFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Risk Levels</option>
            <option value="LOW">Low Risk (0-30)</option>
            <option value="MEDIUM">Medium Risk (31-60)</option>
            <option value="HIGH">High Risk (61-80)</option>
            <option value="CRITICAL">Critical Risk (81-100)</option>
          </select>
        </div>

        <div className="sm:col-span-3">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Mine Types</option>
            <option value="Opencast">Opencast</option>
            <option value="Underground">Underground</option>
            <option value="Mixed">Mixed</option>
          </select>
        </div>

        <div className="sm:col-span-2">
          <button
            onClick={() => setOrder(order === "asc" ? "desc" : "asc")}
            className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs text-slate-300 transition"
          >
            <ArrowUpDown className="w-3.5 h-3.5" />
            <span>{order === "asc" ? "Ascending" : "Descending"}</span>
          </button>
        </div>
      </div>

      {/* Mines Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Code & Name</th>
                <th className="py-3 px-3">Location & District</th>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Capacity</th>
                <th className="py-3 px-3">Compliance</th>
                <th className="py-3 px-3">Risk Level</th>
                <th className="py-3 px-3">Open Violations</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-400" />
                    <span>Loading fleet database...</span>
                  </td>
                </tr>
              ) : mines.length === 0 ? (
                <tr>
                  <td colSpan="8" className="py-12 text-center text-slate-500">
                    No mines matching your search filters.
                  </td>
                </tr>
              ) : (
                mines.map((mine) => (
                  <tr key={mine.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white">{mine.name}</div>
                      <div className="font-mono text-[10px] text-slate-500">{mine.code}</div>
                    </td>
                    <td className="py-3.5 px-3">
                      <div>{mine.district}, {mine.state}</div>
                      <div className="text-[10px] text-slate-500">{mine.location}</div>
                    </td>
                    <td className="py-3.5 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                        mine.mine_type === "Underground"
                          ? "bg-purple-950 text-purple-300 border border-purple-800"
                          : "bg-blue-950 text-blue-300 border border-blue-800"
                      }`}>
                        {mine.mine_type}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 font-mono">{mine.production_capacity} MTPA</td>
                    <td className="py-3.5 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full ${mine.compliance_score >= 80 ? "bg-emerald-500" : "bg-amber-500"}`}
                            style={{ width: `${mine.compliance_score}%` }}
                          />
                        </div>
                        <span className="font-bold font-mono text-[11px] text-slate-200">
                          {mine.compliance_score}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-3">
                      <RiskBadge level={mine.risk_level} score={mine.risk_score} />
                    </td>
                    <td className="py-3.5 px-3 font-mono font-bold text-orange-400">
                      {mine.open_violations_count}
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      <button
                        onClick={() => handleOpenRisk(mine)}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold text-indigo-300 hover:text-white bg-indigo-950/70 hover:bg-indigo-900/80 border border-indigo-800/80 transition"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                        <span>AI Risk Breakdown</span>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* AI Risk Explanation Modal (Section 12) */}
      {selectedRiskMine && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-950 border border-indigo-800 flex items-center justify-center text-indigo-400">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">
                    AI-Assisted Risk Explanation Engine
                  </h3>
                  <p className="text-xs text-slate-400">{selectedRiskMine.name}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedRiskMine(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {riskLoading ? (
              <div className="py-12 text-center text-xs text-slate-400">
                <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-indigo-400" />
                Synthesizing multi-modal governance metrics...
              </div>
            ) : riskData ? (
              <div className="space-y-4">
                {/* Score Header */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Composite Risk Score
                    </span>
                    <div className="text-3xl font-extrabold text-white font-mono mt-0.5">
                      {riskData.risk_score} <span className="text-xs font-normal text-slate-400">/ 100</span>
                    </div>
                  </div>
                  <div>
                    <RiskBadge level={riskData.risk_level} showScore={false} size="lg" />
                  </div>
                </div>

                {/* Explainable Factor Breakdown (Section 12) */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Explainable AI Risk Factor Drivers:
                  </h4>
                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                    {riskData.factors.length === 0 ? (
                      <div className="p-3 text-xs text-slate-400 rounded-lg bg-slate-950/60 border border-slate-800">
                        No adverse factors identified. Mine operating within nominal safety baseline.
                      </div>
                    ) : (
                      riskData.factors.map((f, i) => (
                        <div
                          key={i}
                          className="p-3 rounded-lg bg-slate-950/80 border border-slate-800 flex items-center justify-between"
                        >
                          <div>
                            <div className="text-xs font-semibold text-slate-200">{f.factor}</div>
                            <div className="text-[11px] text-slate-400 mt-0.5">{f.description}</div>
                          </div>
                          <span className="font-mono font-bold text-xs text-red-400 px-2 py-1 rounded bg-red-950/50 border border-red-900/60">
                            +{f.impact}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Actionable Recommendations */}
                <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-900/50 space-y-1.5">
                  <h4 className="text-xs font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                    Recommended Supervisory Action:
                  </h4>
                  <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                    {riskData.recommendations.map((rec, i) => (
                      <li key={i}>{rec}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ) : null}

            <div className="pt-2 text-right">
              <button
                onClick={() => setSelectedRiskMine(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
              >
                Close Explanation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Mine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-base font-bold text-white">Register New Coal Mine Block</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMine} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Mine Name</label>
                <input
                  required
                  type="text"
                  value={newMineForm.name}
                  onChange={(e) => setNewMineForm({ ...newMineForm, name: e.target.value })}
                  placeholder="e.g. Talcher Deep Seam Colliery"
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mine Code</label>
                  <input
                    required
                    type="text"
                    value={newMineForm.code}
                    onChange={(e) => setNewMineForm({ ...newMineForm, code: e.target.value })}
                    placeholder="e.g. MINE-OD-11"
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Mine Type</label>
                  <select
                    value={newMineForm.mine_type}
                    onChange={(e) => setNewMineForm({ ...newMineForm, mine_type: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  >
                    <option value="Opencast">Opencast</option>
                    <option value="Underground">Underground</option>
                    <option value="Mixed">Mixed</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">District</label>
                  <input
                    required
                    type="text"
                    value={newMineForm.district}
                    onChange={(e) => setNewMineForm({ ...newMineForm, district: e.target.value })}
                    placeholder="e.g. Angul"
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">State</label>
                  <input
                    required
                    type="text"
                    value={newMineForm.state}
                    onChange={(e) => setNewMineForm({ ...newMineForm, state: e.target.value })}
                    placeholder="e.g. Odisha"
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Location Details</label>
                <input
                  required
                  type="text"
                  value={newMineForm.location}
                  onChange={(e) => setNewMineForm({ ...newMineForm, location: e.target.value })}
                  placeholder="e.g. Bhubaneswari Block Sector 4"
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Capacity (MTPA)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newMineForm.production_capacity}
                    onChange={(e) => setNewMineForm({ ...newMineForm, production_capacity: parseFloat(e.target.value) })}
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Operational Status</label>
                  <select
                    value={newMineForm.operational_status}
                    onChange={(e) => setNewMineForm({ ...newMineForm, operational_status: e.target.value })}
                    className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                  >
                    <option value="Active">Active</option>
                    <option value="Under Review">Under Review</option>
                    <option value="Suspended">Suspended</option>
                    <option value="Maintenance">Maintenance</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 font-bold text-white rounded-lg"
                >
                  Save Mine
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
