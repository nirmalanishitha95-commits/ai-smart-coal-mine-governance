import React, { useState, useEffect } from "react";
import { useOutletContext, Link } from "react-router-dom";
import {
  Mountain, ShieldCheck, ShieldAlert, AlertTriangle, AlertOctagon,
  CheckSquare, ClipboardCheck, Bell, Activity, Sparkles, RefreshCw,
  ArrowUpRight, ArrowDownRight, Layers
} from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { dashboardService } from "../services/api";
import RiskBadge from "../components/RiskBadge";

export default function DashboardPage() {
  const { refreshTrigger, onOpenSimulation } = useOutletContext() || {};
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchDashboard = () => {
    setLoading(true);
    dashboardService.getStats()
      .then((res) => {
        setData(res.data);
        setError(null);
      })
      .catch((err) => {
        console.error(err);
        setError("Unable to load real-time dashboard data. Ensure backend is running.");
      })
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchDashboard();
  }, [refreshTrigger]);

  if (loading && !data) {
    return (
      <div className="py-24 text-center space-y-3">
        <div className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-slate-400">Loading Central Governance Telemetry...</p>
      </div>
    );
  }

  const kpis = [
    { title: "Total Mines Monitored", value: data?.total_mines ?? 10, icon: Mountain, color: "text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20", change: "+10 Active" },
    { title: "Compliant Mines (≥80%)", value: data?.compliant_mines ?? 7, icon: ShieldCheck, color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20", change: "70% Fleet" },
    { title: "Non-Compliant Mines", value: data?.non_compliant_mines ?? 3, icon: ShieldAlert, color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20", change: "Action Needed" },
    { title: "High/Critical Risk Mines", value: data?.high_risk_mines ?? 3, icon: AlertTriangle, color: "text-red-400", bg: "bg-red-500/10", border: "border-red-500/20", change: "High Alert" },
    { title: "Critical Telemetry Alerts", value: data?.critical_alerts ?? 8, icon: Bell, color: "text-rose-400", bg: "bg-rose-500/10", border: "border-rose-500/20", change: "Active" },
    { title: "Open Violations", value: data?.open_violations ?? 22, icon: AlertOctagon, color: "text-orange-400", bg: "bg-orange-500/10", border: "border-orange-500/20", change: "DGMS Queue" },
    { title: "Pending Corrective Actions", value: data?.pending_corrective_actions ?? 16, icon: CheckSquare, color: "text-cyan-400", bg: "bg-cyan-500/10", border: "border-cyan-500/20", change: "In SLA" },
    { title: "Upcoming Inspections", value: data?.upcoming_inspections ?? 6, icon: ClipboardCheck, color: "text-indigo-400", bg: "bg-indigo-500/10", border: "border-indigo-500/20", change: "Next 14 Days" },
  ];

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner & Action Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/40 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              Central Mining Compliance & Risk Command Center
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 rounded">
              LIVE TELEMETRY
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time regulatory governance, Isolation Forest sensor analytics, and statutory enforcement.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={fetchDashboard}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            title="Refresh Data"
          >
            <RefreshCw className="w-4 h-4" />
          </button>

          <button
            onClick={onOpenSimulation}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 shadow-lg shadow-indigo-950/50 transition active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-spin" />
            <span>RUN AI RISK SIMULATION</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-950/60 border border-red-800 text-xs text-red-300 flex items-center justify-between">
          <span>{error}</span>
          <button onClick={fetchDashboard} className="underline font-semibold ml-2">Retry</button>
        </div>
      )}

      {/* 8 Top KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {kpis.map((kpi, idx) => (
          <div
            key={idx}
            className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition space-y-2 relative overflow-hidden"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400 line-clamp-1">{kpi.title}</span>
              <div className={`w-8 h-8 rounded-lg ${kpi.bg} ${kpi.border} border flex items-center justify-center`}>
                <kpi.icon className={`w-4 h-4 ${kpi.color}`} />
              </div>
            </div>
            <div className="flex items-baseline justify-between pt-1">
              <span className="text-2xl font-black text-white font-mono tracking-tight">
                {kpi.value}
              </span>
              <span className="text-[10px] text-slate-500 font-semibold">{kpi.change}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Primary Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Compliance Trend (6-month) */}
        <div className="lg:col-span-8 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Compliance Trajectory Trend</h3>
              <p className="text-[11px] text-slate-400">Monthly fleet compliance average vs 85% statutory benchmark</p>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
              Benchmark: 85%
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data?.compliance_trend || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} />
                <YAxis domain={[60, 100]} stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                  labelStyle={{ color: "#cbd5e1" }}
                />
                <Line type="monotone" dataKey="score" stroke="#10b981" strokeWidth={2.5} dot={{ r: 4 }} name="Actual Score" />
                <Line type="monotone" dataKey="target" stroke="#6366f1" strokeDasharray="5 5" strokeWidth={2} dot={false} name="DGMS Benchmark" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Distribution Donut Chart */}
        <div className="lg:col-span-4 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white">Fleet Risk Distribution</h3>
            <p className="text-[11px] text-slate-400">AI-evaluated risk categorization across 10 active mines</p>
          </div>

          <div className="h-56 w-full relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data?.risk_distribution || []}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={80}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {(data?.risk_distribution || []).map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            {(data?.risk_distribution || []).map((item, i) => (
              <div key={i} className="flex items-center gap-1.5 text-slate-300">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                <span>{item.name.split(" ")[0]}: <strong>{item.value}</strong></span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Secondary Row: Violations by Category & Environmental Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Violations by Category */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Open Violations by Regulatory Category</h3>
              <p className="text-[11px] text-slate-400">Statutory breach concentrations requiring rectification</p>
            </div>
            <Link to="/violations" className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
              View All <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data?.violations_by_category || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="category" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                  labelStyle={{ color: "#cbd5e1" }}
                />
                <Bar dataKey="count" fill="#f97316" radius={[4, 4, 0, 0]} name="Violations" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Environmental Trends */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Environmental Telemetry Trends</h3>
              <p className="text-[11px] text-slate-400">Atmospheric sensor history (Methane % vs CO ppm)</p>
            </div>
            <Link to="/environmental" className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
              Telemetry Hub <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data?.environmental_trends || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                  labelStyle={{ color: "#cbd5e1" }}
                />
                <Legend wrapperStyle={{ fontSize: "11px" }} />
                <Line type="monotone" dataKey="methane" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} name="Methane (%)" />
                <Line type="monotone" dataKey="co" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} name="CO (ppm)" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tertiary Row: Recent Alerts Table & Status Summary */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Bell className="w-4 h-4 text-rose-400" />
              Recent High-Priority Governance Alerts
            </h3>
            <p className="text-[11px] text-slate-400">Triggered by AI Anomaly ML, risk jumps, and overdue inspection deadlines</p>
          </div>
          <Link to="/alerts" className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
            Open Alert Center <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-2.5 px-3">Mine</th>
                <th className="py-2.5 px-3">Alert Type</th>
                <th className="py-2.5 px-3">Severity</th>
                <th className="py-2.5 px-3">Message</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {(data?.recent_alerts || []).map((alert) => (
                <tr key={alert.id} className="hover:bg-slate-800/40 transition">
                  <td className="py-3 px-3 font-semibold text-white">{alert.mine_name}</td>
                  <td className="py-3 px-3 text-slate-300">{alert.alert_type}</td>
                  <td className="py-3 px-3">
                    <RiskBadge level={alert.severity} showScore={false} size="sm" />
                  </td>
                  <td className="py-3 px-3 text-slate-300 max-w-md truncate">{alert.message}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      alert.status === "RESOLVED"
                        ? "bg-emerald-950 text-emerald-400 border border-emerald-800"
                        : alert.status === "ACKNOWLEDGED"
                        ? "bg-blue-950 text-blue-400 border border-blue-800"
                        : "bg-red-950 text-red-400 border border-red-800"
                    }`}>
                      {alert.status}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono text-[11px] text-slate-400">
                    {new Date(alert.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
