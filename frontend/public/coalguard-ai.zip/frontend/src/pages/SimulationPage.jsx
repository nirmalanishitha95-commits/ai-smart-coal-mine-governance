import React, { useState, useEffect } from "react";
import {
  Cpu, Play, RotateCcw, CheckCircle2, AlertTriangle, ShieldCheck,
  Flame, FileCheck2, ArrowRight, Loader2, Sparkles, Building
} from "lucide-react";
import { simulationService, mineService } from "../services/api";

export default function SimulationPage() {
  const [mines, setMines] = useState([]);
  const [selectedMineId, setSelectedMineId] = useState(1);
  const [isRunning, setIsRunning] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [simulationData, setSimulationData] = useState(null);
  const [selectedStep, setSelectedStep] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    mineService.getAll({ limit: 50 }).then((res) => {
      setMines(res.data);
      if (res.data.length > 0) setSelectedMineId(res.data[0].id);
    });
  }, []);

  const handleStartSimulation = async () => {
    setIsRunning(true);
    setError(null);
    setCurrentStepIndex(0);
    setSimulationData(null);
    setSelectedStep(null);

    try {
      const res = await simulationService.run(selectedMineId);
      const data = res.data;
      setSimulationData(data);

      for (let i = 0; i < data.steps.length; i++) {
        await new Promise((resolve) => setTimeout(resolve, 800));
        setCurrentStepIndex(i + 1);
        setSelectedStep(data.steps[i]);
      }
      setIsRunning(false);
    } catch (err) {
      console.error(err);
      setError("Simulation failed to execute. Ensure backend server is running.");
      setIsRunning(false);
    }
  };

  const handleResetBaseline = async () => {
    try {
      await simulationService.reset(selectedMineId);
      setSimulationData(null);
      setCurrentStepIndex(0);
      setSelectedStep(null);
    } catch (err) {
      console.error(err);
    }
  };

  const activeSteps = simulationData?.steps || [];
  const progressPercent = activeSteps.length > 0 ? (currentStepIndex / activeSteps.length) * 100 : 0;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <Cpu className="w-6 h-6 text-amber-400" />
              AI Risk & Governance Simulation Studio
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold text-amber-300 bg-amber-950/60 border border-amber-800 rounded">
              SIH 2026 BENCHMARK
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Autonomous 14-step demonstration of the complete closed-loop AI compliance and risk lifecycle.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedMineId}
            onChange={(e) => setSelectedMineId(parseInt(e.target.value))}
            className="py-2 px-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            {mines.map((m) => (
              <option key={m.id} value={m.id}>{m.name} ({m.code})</option>
            ))}
          </select>

          <button
            disabled={isRunning}
            onClick={handleStartSimulation}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 shadow-lg shadow-indigo-950/50 transition active:scale-95 disabled:opacity-50"
          >
            {isRunning ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Simulating (Step {currentStepIndex}/14)...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>RUN AI RISK SIMULATION</span>
              </>
            )}
          </button>

          <button
            disabled={isRunning}
            onClick={handleResetBaseline}
            className="flex items-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Baseline</span>
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-900 border border-slate-800 rounded-full h-2 overflow-hidden">
        <div
          className="h-full bg-gradient-to-r from-emerald-500 via-amber-500 to-rose-500 transition-all duration-500"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {error && (
        <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-xs text-red-300 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Interactive Workflow Visualizer Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Step List (7 cols) */}
        <div className="lg:col-span-7 space-y-2.5">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              14-Step Regulatory Loop Execution
            </span>
            <span className="text-xs text-slate-500 font-mono">
              Progress: {currentStepIndex} of 14 Completed
            </span>
          </div>

          <div className="space-y-2">
            {[
              { num: 1, title: "Baseline Telemetry Ingestion", tag: "Normal" },
              { num: 2, title: "Hazard Surge Injected (Methane & Dust)", tag: "Spike" },
              { num: 3, title: "Isolation Forest Anomaly Classification", tag: "AI ML" },
              { num: 4, title: "AI Risk Score Re-evaluation", tag: "Risk Engine" },
              { num: 5, title: "Mine Status Escalated to CRITICAL", tag: "Escalation" },
              { num: 6, title: "Critical Alert Broadcasted", tag: "Alert" },
              { num: 7, title: "Officer Review & Acknowledgement", tag: "DGMS Action" },
              { num: 8, title: "Emergency Inspection Dispatched", tag: "Audit" },
              { num: 9, title: "Digital Checklist Finding Recorded", tag: "Checklist" },
              { num: 10, title: "Formal Regulatory Violation Issued", tag: "Violation" },
              { num: 11, title: "Mandatory Corrective Action Assigned", tag: "CAPA" },
              { num: 12, title: "Rectification Evidence Submitted", tag: "Evidence" },
              { num: 13, title: "Officer Verification & Sign-off", tag: "Sign-off" },
              { num: 14, title: "Governance Loop Closed & Risk Normalized", tag: "Resolved" },
            ].map((step, idx) => {
              const liveStep = activeSteps[idx];
              const isDone = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex - 1 && isRunning;
              const isSelected = selectedStep?.step_number === step.num;

              return (
                <div
                  key={step.num}
                  onClick={() => liveStep && setSelectedStep(liveStep)}
                  className={`p-3.5 rounded-xl border transition flex items-start gap-3.5 cursor-pointer ${
                    isSelected
                      ? "bg-slate-800 border-indigo-500 shadow-lg shadow-indigo-950/40"
                      : isDone
                      ? "bg-slate-900/90 border-slate-800 hover:border-slate-700"
                      : "bg-slate-950/40 border-slate-900 opacity-50"
                  }`}
                >
                  <div className="mt-0.5">
                    {isCurrent ? (
                      <Loader2 className="w-4 h-4 text-amber-400 animate-spin" />
                    ) : isDone ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-slate-700 text-[10px] flex items-center justify-center text-slate-500 font-mono">
                        {step.num}
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white">
                        {step.num}. {step.title}
                      </h4>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {step.tag}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {liveStep ? liveStep.description : "Pending simulation trigger..."}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Step Inspector & State Payload (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-4">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <FileCheck2 className="w-4 h-4 text-indigo-400" />
              Real-Time Telemetry & Verification Inspector
            </h3>

            {selectedStep ? (
              <div className="space-y-3 animate-fadeIn">
                <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-xs text-indigo-400 font-semibold">
                    Step {selectedStep.step_number} Record
                  </span>
                  <h4 className="text-sm font-bold text-white mt-1">
                    {selectedStep.title}
                  </h4>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {selectedStep.description}
                  </p>
                </div>

                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Recorded State Payload:
                  </span>
                  <pre className="text-[11px] font-mono text-emerald-400 p-3 bg-slate-950 rounded-xl border border-slate-800 overflow-x-auto max-h-72">
                    {JSON.stringify(selectedStep.details, null, 2)}
                  </pre>
                </div>
              </div>
            ) : (
              <div className="py-24 text-center text-slate-500 text-xs space-y-2">
                <Cpu className="w-8 h-8 mx-auto text-slate-600 animate-pulse" />
                <p>Click "RUN AI RISK SIMULATION" above to start the live 14-step governance trace.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
