import os
import sys
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# Ensure root directory is on PYTHONPATH
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from backend.app.database.session import engine, Base, SessionLocal
from backend.app.services.seed_service import seed_database_if_empty
from backend.app.api import api_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Ensure all tables exist & auto-seed realistic database
    try:
        Base.metadata.create_all(bind=engine)
        db = SessionLocal()
        try:
            seed_database_if_empty(db)
        finally:
            db.close()
        print("Database schema verified and initial demo datasets synchronized.")
    except Exception as e:
        print(f"Database initialization notice: {e}")
    yield
    # Shutdown
    print("CoalGuard AI backend engine gracefully shutting down.")

app = FastAPI(
    title="CoalGuard AI - Smart Governance and Compliance Monitoring System for Coal Mines",
    description="AI-powered compliance, safety, and environmental monitoring for smarter and safer coal mining.",
    version="1.0.0 (SIH 2026)",
    lifespan=lifespan
)

# CORS configuration
origins_env = os.getenv("CORS_ORIGINS", "")
if origins_env:
    allow_origins = [o.strip() for o in origins_env.split(",")]
else:
    allow_origins = [
        "http://localhost:5173",
        "http://localhost:3000",
        "http://127.0.0.1:5173",
        "http://127.0.0.1:3000",
        "*"
    ]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allow_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API
app.include_router(api_router)

@app.get("/")
def root():
    return {
        "project": "CoalGuard AI",
        "title": "AI-Based Smart Governance and Compliance Monitoring System for Coal Mines",
        "tagline": "AI-powered compliance, safety and environmental monitoring for smarter and safer coal mining.",
        "hackathon": "Smart India Hackathon 2026",
        "status": "OPERATIONAL",
        "api_docs": "/docs",
        "disclaimer": "AI-Assisted Risk Assessment - AI assists regulatory officers and does not make final legal decisions."
    }

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "ai_engine": "IsolationForest (Online)",
        "database": "Connected",
        "active_roles": ["SUPER_ADMIN", "GOVERNMENT_OFFICER", "MINE_MANAGER", "INSPECTOR"]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
