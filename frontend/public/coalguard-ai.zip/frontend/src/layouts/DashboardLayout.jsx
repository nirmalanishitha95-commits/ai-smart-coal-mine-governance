import React, { useState } from "react";
import { Outlet, Navigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import Sidebar from "../components/Sidebar";
import SimulationModal from "../components/SimulationModal";
import { useAuth } from "../context/AuthContext";

export default function DashboardLayout() {
  const { isAuthenticated, loading } = useAuth();
  const [isSimOpen, setIsSimOpen] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-slate-400">Loading CoalGuard AI Governance System...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  const handleSimulationComplete = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950 text-slate-100">
      <Navbar onOpenSimulation={() => setIsSimOpen(true)} />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar onOpenSimulation={() => setIsSimOpen(true)} />

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-950/40">
          <div className="max-w-7xl mx-auto space-y-6">
            <Outlet context={{ refreshTrigger, onOpenSimulation: () => setIsSimOpen(true) }} />
          </div>
        </main>
      </div>

      <SimulationModal
        isOpen={isSimOpen}
        onClose={() => setIsSimOpen(false)}
        onComplete={handleSimulationComplete}
      />
    </div>
  );
}
