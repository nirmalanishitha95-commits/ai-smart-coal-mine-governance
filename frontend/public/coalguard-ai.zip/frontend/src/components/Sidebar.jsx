import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard, Mountain, ShieldCheck, ClipboardCheck,
  AlertOctagon, CheckSquare, Gauge, Bell, MapPin, BarChart3,
  FileText, History, Cpu, LogOut, Settings
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

export default function Sidebar({ onOpenSimulation }) {
  const { role, logout } = useAuth();

  // Role permissions checking
  const isSuperAdmin = role === "SUPER_ADMIN";
  const isGovOfficer = role === "GOVERNMENT_OFFICER" || isSuperAdmin;
  const isInspector = role === "INSPECTOR" || isGovOfficer;
  const isMineManager = role === "MINE_MANAGER" || isGovOfficer;

  const navItems = [
    { name: "Dashboard", path: "/dashboard", icon: LayoutDashboard, visible: true },
    { name: "Mines", path: "/mines", icon: Mountain, visible: true },
    { name: "Compliance", path: "/compliance", icon: ShieldCheck, visible: true },
    { name: "Inspections", path: "/inspections", icon: ClipboardCheck, visible: isInspector || isMineManager },
    { name: "Violations", path: "/violations", icon: AlertOctagon, visible: true },
    { name: "Corrective Actions", path: "/corrective-actions", icon: CheckSquare, visible: true },
    { name: "Environmental Telemetry", path: "/environmental", icon: Gauge, visible: true },
    { name: "Alerts Center", path: "/alerts", icon: Bell, visible: true },
    { name: "Interactive Mine Map", path: "/map", icon: MapPin, visible: true },
    { name: "Analytics & Trends", path: "/analytics", icon: BarChart3, visible: isGovOfficer },
    { name: "Reports & Exports", path: "/reports", icon: FileText, visible: isGovOfficer || isMineManager },
    { name: "Audit Logs", path: "/audit-logs", icon: History, visible: isSuperAdmin || role === "GOVERNMENT_OFFICER" },
    { name: "AI Simulation Studio", path: "/simulation", icon: Cpu, visible: true },
  ];

  return (
    <aside className="w-64 border-r border-slate-800 bg-slate-950 flex flex-col shrink-0 min-h-[calc(100vh-4rem)]">
      {/* Navigation Menu */}
      <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
          Compliance & Safety
        </div>

        {navItems
          .filter((item) => item.visible)
          .map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-medium transition ${
                  isActive
                    ? "bg-emerald-600/15 text-emerald-400 border border-emerald-500/30 shadow-sm"
                    : "text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent"
                }`
              }
            >
              <item.icon className="w-4 h-4 shrink-0" />
              <span>{item.name}</span>
            </NavLink>
          ))}
      </div>

      {/* Bottom Section */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950/40 space-y-2">
        <button
          onClick={onOpenSimulation}
          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 border border-slate-700 transition"
        >
          <Cpu className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
          <span>Quick AI Simulator</span>
        </button>

        <div className="px-3 pt-2 text-[10px] text-slate-500 text-center">
          CoalGuard AI v1.0 · DGMS Compliant
        </div>
      </div>
    </aside>
  );
}
