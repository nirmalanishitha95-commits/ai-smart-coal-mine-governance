import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Bell, Shield, Cpu, User, LogOut, ChevronDown, Sparkles, ExternalLink
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { alertService } from "../services/api";

export default function Navbar({ onOpenSimulation }) {
  const { user, role, logout, switchDemoRole } = useAuth();
  const navigate = useNavigate();
  const [unreadCount, setUnreadCount] = useState(0);
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  useEffect(() => {
    const fetchUnread = () => {
      alertService.getUnreadCount()
        .then((res) => setUnreadCount(res.data.unread_count))
        .catch(() => {});
    };
    fetchUnread();
    const interval = setInterval(fetchUnread, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleRoleSwitch = async (targetRole) => {
    setShowRoleDropdown(false);
    await switchDemoRole(targetRole);
    // Role-based redirect as specified in Section 6
    if (targetRole === "SUPER_ADMIN") navigate("/dashboard");
    else if (targetRole === "GOVERNMENT_OFFICER") navigate("/dashboard");
    else if (targetRole === "MINE_MANAGER") navigate("/dashboard");
    else if (targetRole === "INSPECTOR") navigate("/inspections");
  };

  const getRoleLabel = (r) => {
    switch (r) {
      case "SUPER_ADMIN": return "Super Admin (Coal Controller)";
      case "GOVERNMENT_OFFICER": return "Government Officer (DGMS)";
      case "MINE_MANAGER": return "Mine Manager";
      case "INSPECTOR": return "Statutory Inspector";
      default: return r;
    }
  };

  return (
    <header className="sticky top-0 z-30 h-16 w-full border-b border-slate-800 bg-slate-950/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between">
      {/* Left: Brand & Title */}
      <div className="flex items-center gap-3">
        <Link to="/dashboard" className="flex items-center gap-2.5 group">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-emerald-500 via-teal-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-emerald-950/40 group-hover:scale-105 transition">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight text-white group-hover:text-emerald-400 transition">
                CoalGuard <span className="text-emerald-400">AI</span>
              </span>
              <span className="hidden md:inline-block px-1.5 py-0.5 text-[9px] font-bold text-slate-300 bg-slate-800 border border-slate-700 rounded uppercase tracking-wider">
                SIH 2026
              </span>
            </div>
            <p className="hidden lg:block text-[10px] text-slate-400 -mt-0.5">
              Smart Governance & Compliance Monitoring System
            </p>
          </div>
        </Link>
      </div>

      {/* Center: Legal Disclaimer Notice */}
      <div className="hidden xl:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] text-slate-400">
        <span className="w-2 h-2 rounded-full bg-amber-400" />
        <span>AI-Assisted Risk Assessment · Advisory Decision Support</span>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        {/* Run AI Simulation Button */}
        <button
          onClick={onOpenSimulation}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 shadow-md shadow-indigo-950/40 transition active:scale-95"
        >
          <Sparkles className="w-3.5 h-3.5 animate-spin" />
          <span className="hidden sm:inline">Run AI Simulation</span>
          <span className="sm:hidden">Simulate</span>
        </button>

        {/* Alerts Bell */}
        <Link
          to="/alerts"
          className="relative p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
          title="Alerts Center"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold flex items-center justify-center animate-bounce">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Link>

        {/* Demo Role Switcher Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setShowRoleDropdown(!showRoleDropdown);
              setShowUserDropdown(false);
            }}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition"
            title="Switch demo role for evaluation"
          >
            <span className="hidden md:inline text-[11px] text-slate-400">Role:</span>
            <span className="font-semibold text-emerald-400 max-w-[100px] truncate">
              {role}
            </span>
            <ChevronDown className="w-3 h-3 text-slate-500" />
          </button>

          {showRoleDropdown && (
            <div className="absolute right-0 mt-2 w-56 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl py-1 z-50 animate-fadeIn">
              <div className="px-3 py-1.5 border-b border-slate-800 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Quick Role Switcher (SIH)
              </div>
              {[
                { role: "SUPER_ADMIN", label: "Super Admin", sub: "admin@coalguard.gov.in" },
                { role: "GOVERNMENT_OFFICER", label: "Govt Officer", sub: "officer@coalguard.gov.in" },
                { role: "MINE_MANAGER", label: "Mine Manager", sub: "manager@coalguard.gov.in" },
                { role: "INSPECTOR", label: "Inspector", sub: "inspector@coalguard.gov.in" },
              ].map((item) => (
                <button
                  key={item.role}
                  onClick={() => handleRoleSwitch(item.role)}
                  className={`w-full text-left px-3 py-2 text-xs flex flex-col hover:bg-slate-800 transition ${
                    role === item.role ? "bg-slate-800/80 text-emerald-400 font-semibold" : "text-slate-300"
                  }`}
                >
                  <span>{item.label}</span>
                  <span className="text-[10px] text-slate-500">{item.sub}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* User Profile & Logout */}
        <div className="relative">
          <button
            onClick={() => {
              setShowUserDropdown(!showUserDropdown);
              setShowRoleDropdown(false);
            }}
            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-800 transition text-slate-300"
          >
            <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-300">
              <User className="w-4 h-4" />
            </div>
          </button>

          {showUserDropdown && (
            <div className="absolute right-0 mt-2 w-64 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl py-2 z-50 animate-fadeIn">
              <div className="px-4 py-2 border-b border-slate-800">
                <p className="text-xs font-semibold text-white truncate">{user?.name || "Officer"}</p>
                <p className="text-[10px] text-slate-400 truncate">{user?.email}</p>
                <span className="inline-block mt-1 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  {getRoleLabel(role)}
                </span>
              </div>
              <div className="py-1">
                <Link
                  to="/landing"
                  onClick={() => setShowUserDropdown(false)}
                  className="flex items-center gap-2 px-4 py-2 text-xs text-slate-300 hover:bg-slate-800 hover:text-white transition"
                >
                  <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                  Public Landing Page
                </Link>
                <button
                  onClick={() => {
                    setShowUserDropdown(false);
                    logout();
                    navigate("/login");
                  }}
                  className="w-full flex items-center gap-2 px-4 py-2 text-xs text-red-400 hover:bg-red-950/40 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
