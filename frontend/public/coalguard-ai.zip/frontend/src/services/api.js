import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000/api";

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Attach JWT token to requests if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("coalguard_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Don't auto-redirect if already on login page
      if (!window.location.pathname.includes("/login")) {
        localStorage.removeItem("coalguard_token");
        localStorage.removeItem("coalguard_user");
      }
    }
    return Promise.reject(error);
  }
);

export const authService = {
  login: (email, password) => api.post("/auth/login", { email, password }),
  register: (userData) => api.post("/auth/register", userData),
  getMe: () => api.get("/auth/me"),
};

export const dashboardService = {
  getStats: () => api.get("/dashboard"),
};

export const mineService = {
  getAll: (params) => api.get("/mines", { params }),
  getById: (id) => api.get(`/mines/${id}`),
  create: (data) => api.post("/mines", data),
  update: (id, data) => api.put(`/mines/${id}`, data),
  delete: (id) => api.delete(`/mines/${id}`),
  getRisk: (id) => api.get(`/mines/${id}/risk`),
};

export const complianceService = {
  getRecords: (params) => api.get("/compliance", { params }),
  getRules: () => api.get("/compliance/rules"),
  updateRecord: (id, data) => api.put(`/compliance/${id}`, data),
};

export const inspectionService = {
  getAll: (params) => api.get("/inspections", { params }),
  getById: (id) => api.get(`/inspections/${id}`),
  schedule: (data) => api.post("/inspections", data),
  submitChecklist: (id, data) => api.post(`/inspections/${id}/checklist`, data),
};

export const violationService = {
  getAll: (params) => api.get("/violations", { params }),
  getById: (id) => api.get(`/violations/${id}`),
  create: (data) => api.post("/violations", data),
  update: (id, data) => api.put(`/violations/${id}`, data),
};

export const correctiveActionService = {
  getAll: (params) => api.get("/corrective-actions", { params }),
  create: (data) => api.post("/corrective-actions", data),
  update: (id, data) => api.put(`/corrective-actions/${id}`, data),
};

export const sensorService = {
  getReadings: (params) => api.get("/sensors/readings", { params }),
  ingest: (data) => api.post("/sensors/readings", data),
  getEnvironmentalSummary: (params) => api.get("/sensors/environmental/summary", { params }),
};

export const alertService = {
  getAll: (params) => api.get("/alerts", { params }),
  getUnreadCount: () => api.get("/alerts/unread-count"),
  acknowledge: (id) => api.put(`/alerts/${id}/acknowledge`),
  resolve: (id) => api.put(`/alerts/${id}/resolve`),
};

export const analyticsService = {
  getAnalytics: (params) => api.get("/analytics", { params }),
};

export const reportService = {
  getSummary: (params) => api.get("/reports/summary", { params }),
  getExportCsvUrl: (reportType, mineId, status) => {
    let url = `${API_BASE_URL}/reports/export-csv?report_type=${reportType}`;
    if (mineId) url += `&mine_id=${mineId}`;
    if (status) url += `&status=${status}`;
    return url;
  },
};

export const auditService = {
  getAll: (params) => api.get("/audit-logs", { params }),
};

export const simulationService = {
  run: (mineId) => api.post("/simulation/run", { mine_id: mineId }),
  reset: (mineId) => api.post(`/simulation/reset?mine_id=${mineId || 1}`),
};

export default api;
