import React from "react";

export const getRiskColor = (level) => {
  switch (level?.toUpperCase()) {
    case "CRITICAL":
      return {
        bg: "bg-red-500/15",
        text: "text-red-400",
        border: "border-red-500/30",
        dot: "bg-red-500",
        ring: "ring-red-500/20"
      };
    case "HIGH":
      return {
        bg: "bg-orange-500/15",
        text: "text-orange-400",
        border: "border-orange-500/30",
        dot: "bg-orange-500",
        ring: "ring-orange-500/20"
      };
    case "MEDIUM":
      return {
        bg: "bg-amber-500/15",
        text: "text-amber-400",
        border: "border-amber-500/30",
        dot: "bg-amber-500",
        ring: "ring-amber-500/20"
      };
    case "LOW":
    default:
      return {
        bg: "bg-emerald-500/15",
        text: "text-emerald-400",
        border: "border-emerald-500/30",
        dot: "bg-emerald-500",
        ring: "ring-emerald-500/20"
      };
  }
};

export default function RiskBadge({ level, score, showScore = true, size = "md" }) {
  const colors = getRiskColor(level);
  const sizeClasses = size === "sm" ? "px-2 py-0.5 text-xs" : "px-2.5 py-1 text-xs font-semibold";

  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border ${colors.bg} ${colors.text} ${colors.border} ${sizeClasses}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${colors.dot} animate-pulse`} />
      <span>{level || "LOW"}</span>
      {showScore && score !== undefined && (
        <span className="opacity-80 font-mono text-[10px]">({Math.round(score)})</span>
      )}
    </span>
  );
}
