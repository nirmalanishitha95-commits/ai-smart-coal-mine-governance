import React, { useState, useEffect } from "react";
import {
  ShieldCheck, Search, Filter, CheckCircle, AlertTriangle, Clock,
  FileText, ExternalLink, Edit3, X, Loader2
} from "lucide-react";
import { complianceService, mineService } from "../services/api";

export default function CompliancePage() {
  const [records, setRecords] = useState([]);
  const [rules, setRules] = useState([]);
  const [mines, setMines] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [categoryFilter, setCategoryFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [mineFilter, setMineFilter] = useState("");

  // Edit Modal
  const [selectedRecord, setSelectedRecord] = useState(null);
  const [editStatus, setEditStatus] = useState("COMPLIANT");
  const [editRemarks, setEditRemarks] = useState("");
  const [editEvidence, setEditEvidence] = useState("");

  const categories = [
    "Safety", "Environmental", "Equipment", "Labour",
    "Documentation", "Emergency preparedness", "Operational compliance"
  ];

  const fetchData = () => {
    setLoading(true);
    Promise.all([
      complianceService.getRecords({
        category: categoryFilter || undefined,
        status: statusFilter || undefined,
        mine_id: mineFilter || undefined
      }),
      complianceService.getRules(),
      mineService.getAll({ limit: 50 })
    ])
      .then(([recRes, rulesRes, minesRes]) => {
        setRecords(recRes.data);
        setRules(rulesRes.data);
        setMines(minesRes.data);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchData();
  }, [categoryFilter, statusFilter, mineFilter]);

  const handleOpenEdit = (rec) => {
    setSelectedRecord(rec);
    setEditStatus(rec.status);
    setEditRemarks(rec.remarks || "");
    setEditEvidence(rec.evidence || "");
  };

  const handleSaveEdit = async (e) => {
    e.preventDefault();
    if (!selectedRecord) return;
    try {
      await complianceService.updateRecord(selectedRecord.id, {
        status: editStatus,
        remarks: editRemarks,
        evidence: editEvidence
      });
      setSelectedRecord(null);
      fetchData();
    } catch (err) {
      alert("Failed to update compliance record.");
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "COMPLIANT":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800">COMPLIANT</span>;
      case "PARTIALLY COMPLIANT":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-400 border border-amber-800">PARTIALLY COMPLIANT</span>;
      case "NON-COMPLIANT":
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-950/80 text-red-400 border border-red-800">NON-COMPLIANT</span>;
      case "PENDING REVIEW":
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-950/80 text-blue-400 border border-blue-800">PENDING REVIEW</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-emerald-400" />
            Statutory Compliance Governance Registry
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Tracking DGMS, MoEFCC, and Central Electricity Authority mining regulations.
          </p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-900/80 border border-slate-800">
        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Filter by Category</label>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Regulatory Categories</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Filter by Status</label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Statuses</option>
            <option value="COMPLIANT">Compliant</option>
            <option value="PARTIALLY COMPLIANT">Partially Compliant</option>
            <option value="NON-COMPLIANT">Non-Compliant</option>
            <option value="PENDING REVIEW">Pending Review</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-semibold text-slate-400 mb-1">Filter by Mine</label>
          <select
            value={mineFilter}
            onChange={(e) => setMineFilter(e.target.value)}
            className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 focus:outline-none focus:border-emerald-500"
          >
            <option value="">All Mines</option>
            {mines.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Compliance Records Table */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/90 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 border-b border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="py-3 px-4">Rule Code & Name</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3">Mine Block</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Last Verified</th>
                <th className="py-3 px-3">Evidence Document</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {loading ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-400">
                    <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2 text-emerald-400" />
                    <span>Loading compliance database...</span>
                  </td>
                </tr>
              ) : records.length === 0 ? (
                <tr>
                  <td colSpan="7" className="py-12 text-center text-slate-500">
                    No compliance records found for selected criteria.
                  </td>
                </tr>
              ) : (
                records.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white">{r.rule_name}</div>
                      <div className="font-mono text-[10px] text-slate-500">{r.rule_code}</div>
                    </td>
                    <td className="py-3.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300 border border-slate-700">
                        {r.category}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 font-semibold text-slate-200">
                      {r.mine_name}
                    </td>
                    <td className="py-3.5 px-3">
                      {getStatusBadge(r.status)}
                    </td>
                    <td className="py-3.5 px-3 font-mono text-slate-400 text-[11px]">
                      {r.last_verified ? new Date(r.last_verified).toLocaleDateString() : "Pending"}
                    </td>
                    <td className="py-3.5 px-3">
                      {r.evidence ? (
                        <span className="inline-flex items-center gap-1 font-mono text-[10px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/60">
                          <FileText className="w-3 h-3" />
                          <span className="max-w-[120px] truncate">{r.evidence}</span>
                        </span>
                      ) : (
                        <span className="text-slate-500 text-[10px]">No attachment</span>
                      )}
                    </td>
                    <td className="py-3.5 px-3 text-right">
                      <button
                        onClick={() => handleOpenEdit(r)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                        title="Update Record"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Record Modal */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white">Update Statutory Compliance</h3>
              <button onClick={() => setSelectedRecord(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Rule & Target Mine</label>
                <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-white font-medium">
                  {selectedRecord.rule_name}
                  <div className="text-[10px] text-emerald-400 mt-0.5">{selectedRecord.mine_name}</div>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Compliance Status</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value)}
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                >
                  <option value="COMPLIANT">COMPLIANT</option>
                  <option value="PARTIALLY COMPLIANT">PARTIALLY COMPLIANT</option>
                  <option value="NON-COMPLIANT">NON-COMPLIANT</option>
                  <option value="PENDING REVIEW">PENDING REVIEW</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Evidence Document Name</label>
                <input
                  type="text"
                  value={editEvidence}
                  onChange={(e) => setEditEvidence(e.target.value)}
                  placeholder="e.g. quarterly_inspection_cert_2026.pdf"
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Supervisory Remarks</label>
                <textarea
                  rows={3}
                  value={editRemarks}
                  onChange={(e) => setEditRemarks(e.target.value)}
                  placeholder="Enter regulatory assessment or audit notes..."
                  className="w-full py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-slate-200"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedRecord(null)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 font-bold text-white rounded-lg"
                >
                  Update Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
