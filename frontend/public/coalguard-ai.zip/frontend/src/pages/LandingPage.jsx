import React from "react";
import { Link } from "react-router-dom";
import {
  Shield, Cpu, AlertTriangle, Activity, CheckCircle, ArrowRight,
  Database, FileText, BarChart3, Lock, Users, Building, Layers
} from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col">
      {/* Navigation Bar */}
      <nav className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md sticky top-0 z-50 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-emerald-950/40">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <span className="font-extrabold text-lg tracking-tight text-white">
              CoalGuard <span className="text-emerald-400">AI</span>
            </span>
            <span className="hidden sm:inline-block ml-2 px-2 py-0.5 text-[10px] font-bold text-amber-300 bg-amber-950/70 border border-amber-800 rounded">
              SIH 2026
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Link
            to="/login"
            className="text-xs font-semibold text-slate-300 hover:text-white px-3 py-2 rounded-lg hover:bg-slate-900 transition"
          >
            Portal Sign In
          </Link>
          <Link
            to="/dashboard"
            className="text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 px-4 py-2 rounded-lg shadow-md shadow-emerald-950/40 transition"
          >
            Explore Platform
          </Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative py-20 px-6 overflow-hidden border-b border-slate-800">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.15),rgba(255,255,255,0))]" />

        <div className="max-w-5xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-950/60 border border-emerald-800/80 text-xs font-semibold text-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            Smart India Hackathon 2026 · Ministry of Coal & DGMS Digital Governance
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-tight">
            AI-Based Smart Governance & Compliance Monitoring System for{" "}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-indigo-400">
              Coal Mines
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-3xl mx-auto leading-relaxed">
            “Transforming mine compliance monitoring through AI-assisted risk assessment, intelligent alerts and data-driven governance.”
          </p>

          {/* Legal Advisory Disclaimer */}
          <div className="p-3 max-w-2xl mx-auto rounded-xl bg-slate-900/80 border border-amber-800/40 text-xs text-amber-300 flex items-center justify-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>AI-Assisted Risk Assessment: AI models assist regulatory officers and do not make automated legal decisions.</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <Link
              to="/dashboard"
              className="flex items-center gap-2 px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 shadow-xl shadow-emerald-950/60 transition active:scale-95"
            >
              <span>Explore Platform</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/login"
              className="px-6 py-3.5 rounded-xl font-semibold text-sm text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 transition"
            >
              Officer & Manager Login
            </Link>
          </div>
        </div>
      </section>

      {/* Problem & Solution Grid */}
      <section className="py-16 px-6 max-w-6xl mx-auto w-full space-y-12">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold text-white">The Mining Governance Challenge & Our Solution</h2>
          <p className="text-xs text-slate-400 max-w-xl mx-auto">
            Bridging regulatory oversight, telemetry surveillance, and statutory enforcement.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Problem */}
          <div className="p-6 rounded-2xl bg-red-950/20 border border-red-900/30 space-y-4">
            <div className="w-10 h-10 rounded-xl bg-red-900/50 flex items-center justify-center text-red-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-red-200">The Problem</h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">•</span>
                <span>Manual, paper-based compliance inspections lead to delayed identification of critical safety hazards.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">•</span>
                <span>Underground gas spikes (Methane, Carbon Monoxide) and respirable dust often go unanalyzed until accidents occur.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">•</span>
                <span>No centralized closed-loop system connecting sensor anomalies with statutory corrective action enforcement.</span>
              </li>
            </ul>
          </div>

          {/* Solution */}
          <div className="p-6 rounded-2xl bg-emerald-950/20 border border-emerald-900/30 space-y-4">
            <div className="w-10 h-10 rounded-xl bg-emerald-900/50 flex items-center justify-center text-emerald-400">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-emerald-200">Our Solution: CoalGuard AI</h3>
            <ul className="space-y-2 text-xs text-slate-300">
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Real-time Isolation Forest Machine Learning for continuous telemetric anomaly detection across 8 gas and climate parameters.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>Explainable AI Risk Scoring Engine (0-100) breaking down compliance deficiencies, open violations, and overdue actions.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-emerald-400 font-bold">•</span>
                <span>End-to-end statutory governance workflow: Digital checklists, violation tracking, evidence verification, and audit logs.</span>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Core Modules Grid */}
      <section className="py-16 px-6 bg-slate-900/40 border-y border-slate-800">
        <div className="max-w-6xl mx-auto space-y-10">
          <div className="text-center space-y-2">
            <h2 className="text-2xl font-bold text-white">Full-Stack Enterprise Governance Modules</h2>
            <p className="text-xs text-slate-400 max-w-xl mx-auto">
              Designed for Super Admins, DGMS Officers, Mine Managers, and Safety Inspectors.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Cpu,
                title: "AI Risk Assessment",
                desc: "Explainable rule-based scoring (0-100) evaluating compliance history, violations, incidents, and environmental anomalies.",
                color: "text-indigo-400"
              },
              {
                icon: Activity,
                title: "Isolation Forest Anomaly ML",
                desc: "Detects multi-sensor outliers in Methane, CO, PM10 Dust, Ambient Temp, Humidity, and Acid Mine Water pH.",
                color: "text-emerald-400"
              },
              {
                icon: Shield,
                title: "Compliance Management",
                desc: "Statutory rules across Safety, Environmental, Equipment, Labour, Documentation, and Emergency Preparedness.",
                color: "text-teal-400"
              },
              {
                icon: CheckCircle,
                title: "Digital Inspection Checklist",
                desc: "Interactive 7-question statutory checklist that automatically issues formal violations upon non-conformance.",
                color: "text-cyan-400"
              },
              {
                icon: BarChart3,
                title: "Analytics & Trends",
                desc: "Multi-horizon trend analytics for compliance trajectory, risk distribution, and corrective action SLA completion.",
                color: "text-amber-400"
              },
              {
                icon: Lock,
                title: "Role-Based Access Control",
                desc: "JWT-secured role hierarchy for Super Admin, Government Officer, Mine Manager, and Statutory Inspector.",
                color: "text-purple-400"
              }
            ].map((module, i) => (
              <div
                key={i}
                className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition space-y-3"
              >
                <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                  <module.icon className={`w-4 h-4 ${module.color}`} />
                </div>
                <h4 className="text-sm font-bold text-white">{module.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{module.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto py-8 px-6 border-t border-slate-800 bg-slate-950 text-center text-xs text-slate-500 space-y-2">
        <p className="font-semibold text-slate-400">
          CoalGuard AI · AI-Based Smart Governance and Compliance Monitoring System for Coal Mines
        </p>
        <p>Smart India Hackathon 2026 · Real Working Full-Stack System</p>
      </footer>
    </div>
  );
}
