import React, { useState, useEffect } from "react";
import {
  Gauge, AlertTriangle, ShieldCheck, Activity, Flame, Wind,
  Droplets, Thermometer, Volume2, CloudFog, Sparkles, RefreshCw, Loader2
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { sensorService, mineService } from "../services/api";

export default function EnvironmentalPage() {
  const [data, setData] = useState(null);
  const [mines, setMines] = useState([]);
  const [selectedMineId, setSelectedMineId] = useState(1);
  const [loading, setLoading] = useState(true);
  const [injecting, setInjecting] = useState(false);
  const [injectionSuccess, setInjectionSuccess] = useState(null);

  const fetchEnvironmental = () => {
    setLoading(true);
    Promise.all([
      sensorService.getEnvironmentalSummary({ mine_id: selectedMineId }),
      mineService.getAll({ limit: 50 })
    ])
      .then(([envRes, minesRes]) => {
        setData(envRes.data);
        setMines(minesRes.data);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchEnvironmental();
    const interval = setInterval(fetchEnvironmental, 10000);
    return () => clearInterval(interval);
  }, [selectedMineId]);

  // Inject hazard surge
  const handleInjectSurge = async () => {
    setInjecting(true);
    setInjectionSuccess(null);
    try {
      const res = await sensorService.ingest({
        mine_id: selectedMineId,
        zone: "Shaft 4 - Eastern Extraction Wall",
        methane: 3.45,
        co: 68.0,
        dust: 310.0,
        temperature: 39.2,
        humidity: 86.0,
        noise: 92.0,
        air_quality: 270.0,
        water_quality: 5.4
      });
      setInjectionSuccess("Hazard surge injected! Isolation Forest flagged telemetry as CRITICAL ANOMALY.");
      fetchEnvironmental();
    } catch (err) {
      alert("Failed to inject telemetry.");
    } finally {
      setInjecting(false);
    }
  };

  const getParameterIcon = (id) => {
    switch (id) {
      case "methane": return Flame;
      case "co": return CloudFog;
      case "dust": return Wind;
      case "temperature": return Thermometer;
      case "humidity": return Droplets;
      case "air_quality": return Activity;
      case "water_quality": return Droplets;
      default: return Gauge;
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "CRITICAL":
      case "ANOMALY":
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-400 border border-red-800 animate-pulse">CRITICAL</span>;
      case "WARNING":
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950 text-amber-400 border border-amber-800">WARNING</span>;
      case "NORMAL":
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">NORMAL</span>;
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-slate-900 border border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <Gauge className="w-6 h-6 text-emerald-400" />
              Real-Time Atmospheric & Environmental Telemetry
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-bold text-amber-300 bg-amber-950/60 border border-amber-800 rounded">
              ISOLATION FOREST ONLINE
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Continuous multi-gas telemetry surveillance across active underground and opencast production faces.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <select
            value={selectedMineId}
            onChange={(e) => setSelectedMineId(parseInt(e.target.value))}
            className="py-2 px-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
          >
            {mines.map((m) => (
              <option key={m.id} value={m.id}>{m.name}</option>
            ))}
          </select>

          <button
            disabled={injecting}
            onClick={handleInjectSurge}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 shadow-md shadow-red-950/40 transition active:scale-95 disabled:opacity-50"
          >
            <Flame className="w-3.5 h-3.5 animate-pulse" />
            <span>{injecting ? "Injecting..." : "Simulate Gas Surge"}</span>
          </button>
        </div>
      </div>

      {/* Mandatory Demonstration Disclaimer Notice (Section 11 & 18) */}
      <div className="p-3 rounded-xl bg-slate-900/90 border border-amber-800/60 text-xs text-amber-300 flex items-center justify-between">
        <div className="flex items-center gap-2 font-semibold">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0" />
          <span>DEMO / SIMULATED SENSOR DATA · Smart India Hackathon Live Stream</span>
        </div>
        <span className="text-[11px] text-slate-400 font-mono">
          Last Synced: {data?.last_updated ? new Date(data.last_updated).toLocaleTimeString() : "Just now"}
        </span>
      </div>

      {injectionSuccess && (
        <div className="p-3 rounded-xl bg-red-950/50 border border-red-800 text-xs text-red-300 flex items-center gap-2 animate-fadeIn">
          <AlertTriangle className="w-4 h-4 text-red-400" />
          <span>{injectionSuccess}</span>
        </div>
      )}

      {/* 7 Telemetric Parameter Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {(data?.parameters || []).map((param) => {
          const Icon = getParameterIcon(param.id);
          const isCritical = param.status === "CRITICAL";
          const isWarning = param.status === "WARNING";

          return (
            <div
              key={param.id}
              className={`p-4 rounded-2xl border transition relative overflow-hidden ${
                isCritical
                  ? "bg-red-950/30 border-red-800/80 shadow-lg shadow-red-950/20"
                  : isWarning
                  ? "bg-amber-950/20 border-amber-800/60"
                  : "bg-slate-900/80 border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-400">{param.name}</span>
                <div className="w-8 h-8 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-300">
                  <Icon className="w-4 h-4 text-emerald-400" />
                </div>
              </div>

              <div className="flex items-baseline justify-between mt-3">
                <div className="text-2xl font-black font-mono text-white">
                  {param.value} <span className="text-xs font-normal text-slate-400">{param.unit}</span>
                </div>
                <div>{getStatusBadge(param.status)}</div>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-800/60 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Safe Threshold: {param.threshold} {param.unit}</span>
                <span className="font-semibold text-slate-500">{param.category}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* 24-Hour Historical Telemetry Trend Chart */}
      <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white">Historical Telemetry Stream (Past 24 Hours)</h3>
            <p className="text-[11px] text-slate-400">Time-series tracking of Methane (%), Dust (µg/m³), and Carbon Monoxide (ppm)</p>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
            Real-time Interpolation
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data?.history || []} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="time" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip
                contentStyle={{ backgroundColor: "#0f172a", borderColor: "#334155", borderRadius: "0.5rem" }}
                labelStyle={{ color: "#cbd5e1" }}
              />
              <Legend wrapperStyle={{ fontSize: "11px" }} />
              <Line type="monotone" dataKey="methane" stroke="#ef4444" strokeWidth={2.5} dot={{ r: 3 }} name="Methane (%)" />
              <Line type="monotone" dataKey="co" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} name="CO (ppm)" />
              <Line type="monotone" dataKey="dust" stroke="#38bdf8" strokeWidth={1.5} dot={false} name="Dust PM10 (µg/m³)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
